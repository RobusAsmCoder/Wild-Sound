//////////////////////////////////////////////////////////////////////////////////////
// By Rob F. / Entire Group
//////////////////////////////////////////////////////////////////////////////////////

#include "SysType.h"
#include "hardware.h"
#include "ChipAY_WildSound.h"
#include "ChipAY_Interrupt.h"
#include "ChipAY_Hardware.h"
#include <cstddef>

//__attribute__((section("ROMCODE")))
//__attribute__((section("RAMCODE")))
//__attribute__((section("ccmram")))
#pragma push
#pragma arm section code = "RAMCODE"
#pragma arm section rwdata = "RAMCODE"
#pragma arm section rodata = "RAMCODE"
#pragma arm section zidata = "RAMCODE"


tAY_Struct ayStr={
  .bus              = 0,      //if xxxx78xx then LVD=dibiloid send last Z80 instruction 078EDH="IN A,(C)" to AY ... LVD you was DEBIL and wilbe DEBIL continue
  .dta              = 0xFF,
  .ayn              = 0,
  .ay[0].adr        = 0,
  .ay[1].adr        = 0,
  .WORK_LOCK_BIT    = 0xFF,
  .WORK_MODE        = 0xFF,
  .WORK_CMD         = 0xFF,
  .WORK_STATUS      = 0x00,
  .WORK_POS         = 0x0000,
  .WORK_ERROR       = TSL_AYX32_E_NONE,
  .WORK_FW_SIZE     = 0x0000,
  .WORK_TRANS_TYPE  = TRANS_MODE_USART_SET_115200*0 + TRANS_MODE_USART_SET_ZXUNO,
  .WORK_EMUL_HARD   = 0,
  .WORK_EMUL_ODD    = 1,
};


/*
        DEFDB AY0_R10    ;VOL-C
        DEFDB AY0_R09    ;VOL-B
        DEFDB AY0_R08    ;VOL-A
        DEFDB AY0_R07    ;MASK 0-PLAY
        DEFD  AY0_R00    ;TONE-A
        DEFD  AY0_R01
        DEFD  AY0_R02    ;TONE-B
        DEFD  AY0_R03
        DEFD  AY0_R04    ;TONE-C
        DEFD  AY0_R05
        DEFD  AY0_R06    ;NOISE
        DEFD  AY0_R11    ;ENV
        DEFD  AY0_R12
        DEFD  AY0_R13    ;ENV_MODE
        DEFD  AY0_R14    ;PHASE
        DEFD  AY0_R15    ;PHASE
        DEFD  AY0_Rx0    ;PHASE A
        DEFD  AY0_Rx1    ;PHASE
        DEFD  AY0_Rx2    ;PHASE B
        DEFD  AY0_Rx3    ;PHASE
        DEFD  AY0_Rx4    ;PHASE C
        DEFD  AY0_Rx5    ;PHASE
        DEFD  AY0_RTA    ;TEMP COUNTER A
        DEFD  AY0_RTB    ;TEMP COUNTER B
        DEFD  AY0_RTC    ;TEMP COUNTER C

        DEFDB AY0_CHNP   ;00NNNPPP
        DEFDB AY0_MIX    ;00000DDD
        DEFD  AY0_ENV    ;0..47
*/
#define volMax            ((u16)1024*8)    //256//768
#define volType           1    //0-Lin 1-Log 2-Sin 3-SinLin

#define VBAL_AL           100
#define VBAL_AR            20
#define VBAL_BL            68
#define VBAL_BR            68
#define VBAL_CL            20
#define VBAL_CR           100


#define PutDiver(_t,_v,_w,_x)   ( (u16)( (volType==0) ? ((_t##.0F/15.0F)*volMax) :    \
                                         (volType==1) ? (_v##F*volMax)           :    \
                                         (volType==2) ? (_w##F*volMax)           :    \
                                                        (_x##F*volMax) ) )
//#define PutDiverX(_v)     PutDiver(_v),
#define volT_0            PutDiver( 0, 0.0000, 0.0000, 0.0000)   //00 =.0055
#define volT_1            PutDiver( 1, 0.0078, 0.0055, 0.0004)   //01
#define volT_2            PutDiver( 2, 0.0110, 0.0219, 0.0029)   //02
#define volT_3            PutDiver( 3, 0.0156, 0.0489, 0.0098)   //03
#define volT_4            PutDiver( 4, 0.0220, 0.0865, 0.0231)   //04
#define volT_5            PutDiver( 5, 0.0312, 0.1340, 0.0447)   //05
#define volT_6            PutDiver( 6, 0.0441, 0.1910, 0.0764)   //06
#define volT_7            PutDiver( 7, 0.0624, 0.2569, 0.1199)   //07
#define volT_8            PutDiver( 8, 0.0883, 0.3309, 0.1765)   //08
#define volT_9            PutDiver( 9, 0.1250, 0.4122, 0.2473)   //09
#define volT_A            PutDiver(10, 0.1515, 0.5000, 0.3333)   //10
#define volT_B            PutDiver(11, 0.2500, 0.5933, 0.4351)   //11
#define volT_C            PutDiver(12, 0.3030, 0.6910, 0.5528)   //12
#define volT_D            PutDiver(13, 0.5000, 0.7921, 0.6865)   //13
#define volT_E            PutDiver(14, 0.7070, 0.8955, 0.8358)   //14
#define volT_F            PutDiver(15, 1.0000, 1.0000, 1.0)   //15
#define PutVol(_n,_per)   ((u16)((volT_##_n)*_per/100))




#define VolTblGenerator(_cn)      \
const s16 VolTB##_cn[]={          \
  PutVol(0,VBAL_##_cn),           \
  PutVol(1,VBAL_##_cn),           \
  PutVol(2,VBAL_##_cn),           \
  PutVol(3,VBAL_##_cn),           \
  PutVol(4,VBAL_##_cn),           \
  PutVol(5,VBAL_##_cn),           \
  PutVol(6,VBAL_##_cn),           \
  PutVol(7,VBAL_##_cn),           \
  PutVol(8,VBAL_##_cn),           \
  PutVol(9,VBAL_##_cn),           \
  PutVol(A,VBAL_##_cn),           \
  PutVol(B,VBAL_##_cn),           \
  PutVol(C,VBAL_##_cn),           \
  PutVol(D,VBAL_##_cn),           \
  PutVol(E,VBAL_##_cn),           \
  PutVol(F,VBAL_##_cn)            \
}

VolTblGenerator(AL);
VolTblGenerator(AR);
VolTblGenerator(BL);
VolTblGenerator(BR);
VolTblGenerator(CL);
VolTblGenerator(CR);
/*
u16 VolTAB[16]={
        PutDiverX(0.0000)   //00 =.0055
        PutDiverX(0.0078)   //01
        PutDiverX(0.0110)   //02
        PutDiverX(0.0156)   //03
        PutDiverX(0.0220)   //04
        PutDiverX(0.0312)   //05
        PutDiverX(0.0441)   //06
        PutDiverX(0.0624)   //07
        PutDiverX(0.0883)   //08
        PutDiverX(0.1250)   //09
        PutDiverX(0.1515)   //10
        PutDiverX(0.2500)   //11
        PutDiverX(0.3030)   //12
        PutDiverX(0.5000)   //13
        PutDiverX(0.7070)   //14
        PutDiverX(1.0000)   //15
};
*/
u8 NoiseTAB[256]={
0x9C,0xFB,0x1F,0xD2,0x4D,0x07,0xEA,0x6B,0x18,0x35,0x1B,0xD6,0x1C,0xD4,0xDC,0xB5,
0x1F,0xCF,0xC6,0xCA,0x2D,0x1C,0xD5,0xD6,0x21,0x0F,0xE3,0x2C,0x7F,0x7F,0x2A,0xFE,
0x9C,0x7F,0x22,0x5F,0x47,0x05,0xE6,0xAD,0x42,0xE3,0x0C,0xE8,0x67,0x0B,0xE5,0x0E,
0xE8,0xAB,0x9E,0x3A,0x65,0xA6,0xF1,0x49,0x22,0x31,0xA9,0xF1,0x04,0x05,0xEB,0xA7,
0x13,0x38,0x95,0x07,0x72,0xE2,0xE6,0xB1,0x17,0xDE,0xE9,0x0C,0x44,0x0E,0xE9,0xFF,
0x2D,0x1D,0xD7,0xB9,0x42,0x7B,0xF5,0x8B,0xF7,0xFA,0xB6,0x3C,0xB7,0x5A,0xF7,0xDE,
0x14,0xE4,0xB2,0x88,0x06,0x74,0x7F,0x75,0x35,0x79,0xD4,0x21,0x7F,0x53,0x56,0xFB,
0x99,0xA1,0x5A,0x2F,0x7F,0x29,0x24,0x4A,0x97,0x3F,0x11,0xFF,0xF1,0xA6,0xED,0xF1,
0x01,0xF5,0x7A,0x34,0x20,0x3E,0xF2,0xA2,0xF4,0xFA,0xFB,0xF2,0x03,0x51,0xFD,0xF3,
0x7F,0x75,0xA6,0x54,0x34,0x15,0x3B,0x12,0xA4,0x94,0x44,0x1F,0xF4,0x8E,0x4F,0x5C,
0xB0,0xE0,0x16,0x3A,0xB9,0xDA,0x0D,0xE8,0xBE,0x36,0xBC,0x39,0x10,0xB0,0xEB,0xE3,
0xB3,0xE3,0x6C,0x72,0x35,0x1D,0x31,0xEA,0x18,0x76,0xDA,0x1D,0x26,0x8E,0xBD,0xDC,
0x1D,0x1C,0x21,0x30,0x39,0x2B,0xCB,0x76,0x3A,0xCA,0x2E,0x25,0xAC,0xE2,0x0F,0xE9,
0xAC,0x8F,0x39,0x16,0xAE,0xE7,0x3F,0x70,0xE2,0x19,0x3B,0x0A,0x0B,0xE5,0x0C,0x45,
0xAE,0x8D,0xAE,0x01,0x50,0x4B,0xED,0x7F,0x7F,0xA8,0xEF,0x64,0xF8,0x1F,0x33,0xC6,
0xCE,0x34,0x24,0x09,0x92,0xD6,0x20,0x3A,0x19,0x08,0x4D,0x03,0x4B,0xA7,0xFD,0x32
};

u8 EnvTAB[768]={
15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,  // 0
15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,  // 1
15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,  // 2
15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,  // 3

 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,  // 4
 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,  // 5
 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,  // 6
 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,  // 7

15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,  // 8
15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,  // 9
15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,  //10
15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,  //11

 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,  //12
 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,  //13
 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,  //14
 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,  //15
  
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 0
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 1
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 2
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 3

 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 4
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 5
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 6
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 7

15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,  // 8
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 9
 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,  //10
15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,  //11

 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,  //12
15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,  //13
15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,  //14
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  //15

 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 0
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 1
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 2
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 3

 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 4
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 5
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 6
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 7

15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,  // 8
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 9
15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,  //10
15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,  //11

 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,  //12
15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,  //13
 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,  //14
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  //15
};


/*

#define ayStepTone(_num)                                                                      \
      uu16(AY->REG.ST.CTNE[_num])--;                                                          \
      if (AY->REG.ST.CTNE[_num].CNT==AY->REG.ST.PHASE[_num]) AY->REG.ST.CTNE[_num].MIX=0;     \
      if ((AY->REG.ST.CTNE[_num].CNT==0))                                                     \
      {                                                                                       \
        AY->REG.ST.CTNE[_num].OVR=0;                                                          \
        AY->REG.ST.CTNE[_num].CNT=AY->REG.ST.TONE[_num];                                      \
        AY->REG.ST.CTNE[_num].MIX=1;                                                          \
      }

#define ayStepMix(_n, _abc, _v, _vp)                                                                                  \
      if ( (AY->REG.ST.CTNE[_n].MIX | AY->REG.ST.MIXER.T##_abc) & (AY->REG.ST.CNOI.MIX | AY->REG.ST.MIXER.N##_abc) )  \
      {                                                                                                               \
        _v=AY->REG.ST.VOL[_n];                                                                                        \
        if (_v&0x10)                                                                                                  \
        {                                                                                                             \
          _v=_vp;                                                                                                     \
        }                                                                                                             \
      } else {                                                                                                        \
        _v=0;                                                                                                         \
      }

void ChipAY_Tiks(tChipAY *AY, tsbSys *sb, u16 tiks, u16 isStoreSbPointer)
{
    u16 *bL=sb->L.buf;
    u16 *bR=sb->R.buf;
    u16 pL=sb->L.pos;
    u16 pR=sb->R.pos;
  
    while (tiks)
    {
      u8 v,vp;
      u16 vpt; 
      u16 vl,vr;
     //TONE
      ayStepTone(0);      //TONE STEP A
      ayStepTone(1);      //TONE STEP B
      ayStepTone(2);      //TONE STEP C
     //NOISE
      uu8(AY->REG.ST.CNOI)--;
//      if (AY->REG.ST.CNOI.OVR)
      if (AY->REG.ST.CNOI.CNT==0)
      {
        //AY->REG.ST.CNOI.OVR=0;
        AY->REG.ST.CNOI.CNT=AY->REG.ST.NOISE;
        if (AY->REG.ST.CNOI.RND==0) AY->REG.ST.CNOI.RND = NoiseTAB[AY->REG.ST.CNOI.PTR++];
        AY->REG.ST.CNOI.MIX = AY->REG.ST.CNOI.RND;
        AY->REG.ST.CNOI.RND>>=1;
      }
     //ENVELOUPMENT
      vpt=AY->REG.ST.CENV.PTR;
      vp=EnvTAB[vpt | (AY->REG.ST.ENVEFF<<4)];
      uu32(AY->REG.ST.CENV)--;
      if ( AY->REG.ST.CENV.CNT==0)
      {
        AY->REG.ST.CENV.CNT=AY->REG.ST.ENV;
        vpt++;
        if (vpt&0x0F0)
        {
          vpt+=0x0F0;
          if (vpt==0x300)
          {
            vpt=0x100;
          }
        }
        AY->REG.ST.CENV.PTR=vpt;
      }
     //MIXER
      ayStepMix(0,A,v,vp);
      vl =VolTBAL[v];
      vr =VolTBAR[v];
      ayStepMix(1,B,v,vp);
      vl+=VolTBBL[v];
      vr+=VolTBBR[v];
      ayStepMix(2,C,v,vp);
      vl+=VolTBCL[v];
      vr+=VolTBCR[v];
    
      bL[pL]+=vl;
      bR[pR]+=vr;
      SB_IncrementBufer(pL);
      SB_IncrementBufer(pR);
      
      tiks--;
    }
    if (isStoreSbPointer)
    {
      sb->L.pos = pL;
      sb->R.pos = pR;
    }
    
}
*/



#define TBLsetAT(_p,_v)    [(_p)]=_v
#define TBLsetARR_F(p,v0,v1,v2,v3,v4,v5,v6,v7,v8,v9,vA,vB,vC,vD,vE,vF)   \
                              TBLsetAT(p+ 0*16,0x##v0), \
                              TBLsetAT(p+ 1*16,0x##v1), \
                              TBLsetAT(p+ 2*16,0x##v2), \
                              TBLsetAT(p+ 3*16,0x##v3), \
                              TBLsetAT(p+ 4*16,0x##v4), \
                              TBLsetAT(p+ 5*16,0x##v5), \
                              TBLsetAT(p+ 6*16,0x##v6), \
                              TBLsetAT(p+ 7*16,0x##v7), \
                              TBLsetAT(p+ 8*16,0x##v8), \
                              TBLsetAT(p+ 9*16,0x##v9), \
                              TBLsetAT(p+10*16,0x##vA), \
                              TBLsetAT(p+11*16,0x##vB), \
                              TBLsetAT(p+12*16,0x##vC), \
                              TBLsetAT(p+13*16,0x##vD), \
                              TBLsetAT(p+14*16,0x##vE), \
                              TBLsetAT(p+15*16,0x##vF)
#define _D(p,pp)    TBLsetARR_F((p)*256+pp, F,E,D,C,B,A,9,8,7,6,5,4,3,2,1,0)
#define _U(p,pp)    TBLsetARR_F((p)*256+pp, 0,1,2,3,4,5,6,7,8,9,A,B,C,D,E,F)
#define _L(p,pp)    TBLsetARR_F((p)*256+pp, 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)
#define _H(p,pp)    TBLsetARR_F((p)*256+pp, F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F)
#define _TBL(p, v0,v1,v2)    _##v0(0,0x##p), _##v1(1,0x##p), _##v2(2,0x##p)

const u8 EnvRndTAB[1024]={
_TBL(0,D,L,L),// 0 { \_____ }
_TBL(1,D,L,L),// 1 { \_____ }
_TBL(2,D,L,L),// 2 { \_____ }
_TBL(3,D,L,L),// 3 { \_____ }
_TBL(4,U,L,L),// 4 { /_____ }
_TBL(5,U,L,L),// 5 { /_____ }
_TBL(6,U,L,L),// 6 { /_____ }
_TBL(7,U,L,L),// 7 { /_____ }
_TBL(8,D,D,D),// 8 { \\\\\\ }
_TBL(9,D,L,L),// 9 { \_____ }
_TBL(A,D,U,D),// A { \/\/\/ }
_TBL(B,D,H,H),// B { \----- }
_TBL(C,U,U,U),// C { ////// }
_TBL(D,U,H,H),// D { /----- } 
_TBL(E,U,D,U),// E { /\/\/\ }
_TBL(F,U,L,L),// F { /_____ }
[768]=0x9C,0xFB,0x1F,0xD2,0x4D,0x07,0xEA,0x6B,0x18,0x35,0x1B,0xD6,0x1C,0xD4,0xDC,0xB5,
      0x1F,0xCF,0xC6,0xCA,0x2D,0x1C,0xD5,0xD6,0x21,0x0F,0xE3,0x2C,0x7F,0x7F,0x2A,0xFE,
      0x9C,0x7F,0x22,0x5F,0x47,0x05,0xE6,0xAD,0x42,0xE3,0x0C,0xE8,0x67,0x0B,0xE5,0x0E,
      0xE8,0xAB,0x9E,0x3A,0x65,0xA6,0xF1,0x49,0x22,0x31,0xA9,0xF1,0x04,0x05,0xEB,0xA7,
      0x13,0x38,0x95,0x07,0x72,0xE2,0xE6,0xB1,0x17,0xDE,0xE9,0x0C,0x44,0x0E,0xE9,0xFF,
      0x2D,0x1D,0xD7,0xB9,0x42,0x7B,0xF5,0x8B,0xF7,0xFA,0xB6,0x3C,0xB7,0x5A,0xF7,0xDE,
      0x14,0xE4,0xB2,0x88,0x06,0x74,0x7F,0x75,0x35,0x79,0xD4,0x21,0x7F,0x53,0x56,0xFB,
      0x99,0xA1,0x5A,0x2F,0x7F,0x29,0x24,0x4A,0x97,0x3F,0x11,0xFF,0xF1,0xA6,0xED,0xF1,
      0x01,0xF5,0x7A,0x34,0x20,0x3E,0xF2,0xA2,0xF4,0xFA,0xFB,0xF2,0x03,0x51,0xFD,0xF3,
      0x7F,0x75,0xA6,0x54,0x34,0x15,0x3B,0x12,0xA4,0x94,0x44,0x1F,0xF4,0x8E,0x4F,0x5C,
      0xB0,0xE0,0x16,0x3A,0xB9,0xDA,0x0D,0xE8,0xBE,0x36,0xBC,0x39,0x10,0xB0,0xEB,0xE3,
      0xB3,0xE3,0x6C,0x72,0x35,0x1D,0x31,0xEA,0x18,0x76,0xDA,0x1D,0x26,0x8E,0xBD,0xDC,
      0x1D,0x1C,0x21,0x30,0x39,0x2B,0xCB,0x76,0x3A,0xCA,0x2E,0x25,0xAC,0xE2,0x0F,0xE9,
      0xAC,0x8F,0x39,0x16,0xAE,0xE7,0x3F,0x70,0xE2,0x19,0x3B,0x0A,0x0B,0xE5,0x0C,0x45,
      0xAE,0x8D,0xAE,0x01,0x50,0x4B,0xED,0x7F,0x7F,0xA8,0xEF,0x64,0xF8,0x1F,0x33,0xC6,
      0xCE,0x34,0x24,0x09,0x92,0xD6,0x20,0x3A,0x19,0x08,0x4D,0x03,0x4B,0xA7,0xFD,0x32,
};




////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

void ChipAY_WriteReg(tChipAY *AY, u8 r, u8 v)
{
    if (r<sizeof(AY->REG.R))
    {
      AY->REG.R[r] = v;
      if (r<32)
      {
        if ( ((u32)AY) == (u32)&ayStr.ay[0] ) EXT_DoAyReneratorUpdate(0, (r & 0x1F));
        if ( ((u32)AY) == (u32)&ayStr.ay[1] ) EXT_DoAyReneratorUpdate(1, (r & 0x1F));
      }
    }
}
//Synthesizer_Stereo16_P
void ChipAY_Init(tChipAY *AY)
{
  /*
    u32 n;
    //AY[0].ST.TONE[0]++;
    for (n=0; n<16; n++)
    {
      AY->REG.R[n]=0;
    }
    uu8(AY->REG.ST.MIXER) = 0x3F;
*/
    ChipAY_WriteReg(AY,  0, 0x00);
    ChipAY_WriteReg(AY,  1, 0x00);
    ChipAY_WriteReg(AY,  2, 0x00);
    ChipAY_WriteReg(AY,  3, 0x00);
    ChipAY_WriteReg(AY,  4, 0x00);
    ChipAY_WriteReg(AY,  5, 0x00);
    ChipAY_WriteReg(AY,  6, 0x01);
    ChipAY_WriteReg(AY,  7, 0x3F);
    ChipAY_WriteReg(AY,  8, 0x00);
    ChipAY_WriteReg(AY,  9, 0x00);
    ChipAY_WriteReg(AY, 10, 0x00);
    ChipAY_WriteReg(AY, 11, 01*0);
    ChipAY_WriteReg(AY, 12, 02*0);
    ChipAY_WriteReg(AY, 13, 0x00);
    ChipAY_WriteReg(AY, 14, 0xFF);
    ChipAY_WriteReg(AY, 15, 0xFF);
    
    ChipAY_WriteReg(AY, 24, 0x80);
    ChipAY_WriteReg(AY, 25, 0x80);
    ChipAY_WriteReg(AY, 26, 0x80);
  
  
}

#define isUseProcedureCall    0

#define ayStepMix(AY, _n, _abc, _v, _vp, _TNE, _NOI)                                                                  \
      if ( (_TNE | AY.REG.ST.MIXER.T##_abc) & (_NOI | AY.REG.ST.MIXER.N##_abc) )                                      \
      {                                                                                                               \
        _v=AY.REG.ST.VOL[_n];                                                                                         \
        if (_v&0x10)                                                                                                  \
        {                                                                                                             \
          _v=_vp;                                                                                                     \
        }                                                                                                             \
      } else {                                                                                                        \
        _v=0;                                                                                                         \
      }

//OUT:0xRRRRLLLL - R,L - 16-bit DAC value
//__attribute__((section("RAMCODE")))
u32 ChipAY_Mixer(tAY_Struct *ays)
{
      u32 dacv=0x80008000;
    
      u16 vl0,vr0;
      u16 vl1,vr1;
    
      static u16 ay0no=0;
      static u16 ay1no=0;
      static u8 no0i=1;
      static u8 no1i=1;
    #if isUseProcedureCall
      const u8  t0a= AY0TONEA_PWMcur();
      const u8  t0b= AY0TONEB_PWMcur();
      const u8  t0c= AY0TONEC_PWMcur();
      const u8  t1a= AY1TONEA_PWMcur();
      const u8  t1b= AY1TONEB_PWMcur();
      const u8  t1c= AY1TONEC_PWMcur();
      const u16 e0e=(AY0ENV_CNMcur(32)) & 0x1F;
      const u16 e1e=(AY1ENV_CNMcur(32)) & 0x1F;
      const u16 n0n= AY0NOI_CNTcur();
      const u16 n1n= AY1NOI_CNTcur();
     #else
      const u8  t0a= AYxPWMcur(AY0TONEA);
      const u8  t0b= AYxPWMcur(AY0TONEB);
      const u8  t0c= AYxPWMcur(AY0TONEC);
      const u8  t1a= AYxPWMcur(AY1TONEA);
      const u8  t1b= AYxPWMcur(AY1TONEB);
      const u8  t1c= AYxPWMcur(AY1TONEC);
      //const u16 e0e=(AYxCNTcur(AY0ENV)) & 0x1F; 
      //const u16 e1e=(AYxCNTcur(AY1ENV)) & 0x1F; 
      const u16 e0e=(AYxCNMcur(AY0ENV,32)) & 0x1F;
      const u16 e1e=(AYxCNMcur(AY1ENV,32)) & 0x1F;
      //const u16 n0n= AYxCNTcur(AY0NOI) & 2047; // AYxCNMcur(AY0NOI,2048);
      //const u16 n1n= AYxCNTcur(AY1NOI) & 2047; // AYxCNMcur(AY1NOI,2048);
      //const u16 n0n= AYxCNMcur(AY0NOI,256);
      //const u16 n1n= AYxCNMcur(AY1NOI,256);
      const u16 n0n= AYxPWMcur(AY0NOI);
      const u16 n1n= AYxPWMcur(AY1NOI);
     #endif

      u8 v;     //tmp for calc 0..15
      u8 vp;    //current Volume of ENV
      //u8 noi;
      u8 ex;
      u8 ey;
      
      if (ay0no != n0n) { no0i = RNG->DR & 1; ay0no = n0n; }
      if (ay1no != n1n) { no1i = RNG->DR & 1; ay1no = n1n; }
      //if (ay0no ^ n0n) { no0i = RNG->DR & 1; } ay0no = n0n;
      //if (ay1no ^ n1n) { no1i = RNG->DR & 1; } ay0no = n1n;
      
      //noi = (NoiseTAB[(u8)(n0n>>3)] >> ((n0n) & 7)) & 1;
      ex = ays->ay[0].REG.ST.ENVEFF;
      ey = e0e;
      vp = EnvRndTAB[ 16*16 + ey*16 + ex ];
      ayStepMix( ays->ay[0], 0,A,v,vp, t0a, no0i);
      vl0 = VolTBAL[v];
      vr0 = VolTBAR[v];
      ayStepMix( ays->ay[0], 1,B,v,vp, t0b, no0i);
      vl0+= VolTBBL[v];
      vr0+= VolTBBR[v];
      ayStepMix( ays->ay[0], 2,C,v,vp, t0c, no0i);
      vl0+= VolTBCL[v];
      vr0+= VolTBCR[v];

      //noi = NoiseTAB[(u8)(n1n>>3)] >> ((n0n) & 7) & 1;
      ex = ays->ay[1].REG.ST.ENVEFF;
      ey = e1e;
      vp = EnvRndTAB[ 16*16 + ey*16 + ex ];
      ayStepMix( ays->ay[1], 0,A,v,vp, t1a, no1i);
      vl1 = VolTBAL[v];
      vr1 = VolTBAR[v];
      ayStepMix( ays->ay[1], 1,B,v,vp, t1b, no1i);
      vl1+= VolTBBL[v];
      vr1+= VolTBBR[v];
      ayStepMix( ays->ay[1], 2,C,v,vp, t1c, no1i);
      vl1+= VolTBCL[v];
      vr1+= VolTBCR[v];


      u16 vl;
      u16 vr;
#define bufsize 10*0
#if bufsize
      static u16 bufl[bufsize];
      static u16 bufr[bufsize];
      static u16 buP=0;
#endif      
      if (1)
      {
//        vl=((u16)((0x0800-vl0)+vl1)) & 0x0FFF;
//        vr=((u16)((0x0800-vr0)+vr1)) & 0x0FFF;
        vl=((u16)((0x8000-vl0)+vl1));// & 0xFFFF;
        vr=((u16)((0x8000-vr0)+vr1));// & 0xFFFF;
      } else {
        vl=((u16)(0x0800+vl0+vl1)) & 0x0FFF;
        vr=((u16)(0x0800+vr0+vr1)) & 0x0FFF;
      }
#if bufsize
      bufl[buP]=vl;
      bufr[buP]=vr;
      buP = (buP + 1) % bufsize;
      const u16 buPP = (buP + bufsize/4) % bufsize;
      vl = vl + (bufl[buP] / 2) - (bufl[buPP] / 4);
      vr = vr + (bufr[buP] / 2) - (bufl[buPP] / 4);
#endif      
      
      dacv = vl | (vr<<16);
      return dacv;
}

#pragma pop

