//////////////////////////////////////////////////////////////////////////////////////
// By Rob F. / Entire Group
//////////////////////////////////////////////////////////////////////////////////////

#ifndef __HARDWARE_H
#define __HARDWARE_H


#include "SysType.h"
#include "hdtimers.h"
#include "hdports.h"
//#include "hdspi.h"
//#include "hdfsmc.h"
/////////////////////////////////////////////////////////////////////////////
// Sys Define
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// Hard Ver 1
/////////////////////////////////////////////////////////////////////////////

#define SWOinputMode    1   // 0-PushPull, 1-OpenDrainPullUp, 2-InputPullUp
//MODE = 1
//OT = 1
//PUPDR = 1
#if SWOinputMode==0
  hdPin_O_DefineSetup(SWO,            B,  3, hd_gptp_OUT_PP,     1);
  #define SWO(_v)                     dH_PORT_Write(SWO,_v)
#elif SWOinputMode==1
  hdPin_O_DefineSetup(SWO,            B,  3, hd_gptp_OUT_PPU,     1);
  #define SWO(_v)                     dH_PORT_Write(SWO,_v)
#else  
  hdPin_O_DefineSetup(SWO,            B,  3, hd_gptp_IN_PPU,     1);
  #define SWO(_v)                     dH_PORT_Write(SWO,_v)
#endif
  #define SWO_OFF()                   SWO(0)
  #define SWO_ON()                    SWO(1)
  #define SWO_GET()                   dH_PORTvRead(SWO)

///  hdPin_O_DefineSetup(AY_BOOT,        A,  2, hd_gptp_IN_OD,     0);
///  #define AY_RESET()                  dH_PORTvRead(AY_RESET)

//  hdPin_O_DefineSetup(TIM1CH2,        A,  9, hd_gptp_AF_PP,     1);
//  #define TIM1CH2()                   dH_PORT_Read(TIM1CH2)
  //hdPin_O_DefineSetup(TIM1CH3,        A, 10, hd_gptp_AF_PP,     1);
//  hdPin_O_DefineSetup(DACTEST,        A, 10, hd_gptp_OUT_PP,     1);
//  #define DACTEST(_v)                 dH_PORT_Write(DACTEST,_v)


  hdPin_O_DefineSetup(USARTZXUNO_TX,      A,  9, hd_gptp_OUT_PP,     1);
  #define USARTZXUNO_TX(_v)               dH_PORT_Write(USARTZXUNO_TX,_v)
  hdPin_O_DefineSetup(USARTZXUNO_RX,      A, 10, hd_gptp_IN_OD,      1);
  #define USARTZXUNO_RX()                 dH_PORTvRead(USARTZXUNO_RX)

/////////////////////////////////////////////////////////////////////////////
  hdPin_O_DefineSetup(DAC1,           A,  4, hd_gptp_AN_OD,     1);
  hdPin_O_DefineSetup(DAC2,           A,  5, hd_gptp_AN_OD,     1);
/////////////////////////////////////////////////////////////////////////////


  hdPin_O_DefineSetup(AY_BDIR,        B,  0, hd_gptp_IN_OD,     0);
  #define AY_BDIR()                   dH_PORT_Read(AY_BDIR)
  hdPin_O_DefineSetup(AY_BC1,         B,  1, hd_gptp_IN_OD,     0);
  #define AY_BC1()                    dH_PORT_Read(AY_BC1)

  #define PRTB_DIR                    hd_gptp_IN_PPU
  #define PRTB_DIRp                   hd_gptp_IN_OD   //hd_gptp_IN_PPD //hd_gptp_OUT_OD

  hdPin_O_DefineSetup(AY_RESET,       A,  2, hd_gptp_IN_OD,     0);
  #define AY_RESET()                  dH_PORTvRead(AY_RESET)


//  hdPin_O_DefineSetup(PRTB0,          B,  0, PRTB_DIR,     0);
//  hdPin_O_DefineSetup(PRTB1,          B,  1, PRTB_DIR,     0);
  hdPin_O_DefineSetup(PRTB2,          B,  2, PRTB_DIR,     0);
  hdPin_O_DefineSetup(PRTB4,          B,  4, PRTB_DIR,     0);
  hdPin_O_DefineSetup(PRTB5,          B,  5, PRTB_DIR,     0);
  hdPin_O_DefineSetup(PRTB6,          B,  6, PRTB_DIR,     0);
  hdPin_O_DefineSetup(PRTB7,          B,  7, PRTB_DIR,     0);
  hdPin_O_DefineSetup(PRTB8,          B,  8, PRTB_DIRp,    3);
  hdPin_O_DefineSetup(PRTB9,          B,  9, PRTB_DIRp,    3);
  hdPin_O_DefineSetup(PRTB10,         B, 10, PRTB_DIRp,    3);
  hdPin_O_DefineSetup(PRTB11,         B, 11, PRTB_DIRp,    3);
  hdPin_O_DefineSetup(PRTB12,         B, 12, PRTB_DIRp,    3);
  hdPin_O_DefineSetup(PRTB13,         B, 13, PRTB_DIRp,    3);
  hdPin_O_DefineSetup(PRTB14,         B, 14, PRTB_DIRp,    3);
  hdPin_O_DefineSetup(PRTB15,         B, 15, PRTB_DIRp,    3);




/////////////////////////////////////////////////////////////////////////////
// Extern Procedures
/////////////////////////////////////////////////////////////////////////////


extern void Init(void);




#endif
