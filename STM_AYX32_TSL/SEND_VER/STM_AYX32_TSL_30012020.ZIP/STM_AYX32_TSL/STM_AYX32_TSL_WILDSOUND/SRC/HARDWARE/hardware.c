//////////////////////////////////////////////////////////////////////////////////////
// 
// Low level for STM32F100
// 
// By Rob F. / Entire Group
// 
//////////////////////////////////////////////////////////////////////////////////////

#include "SysType.h"
#include "hardware.h"
//#include "STM32_Init.h"

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////// 
////////////////////////////////////////////////////////////////////////////////////////////////////////// 
////////////////////////////////////////////////////////////////////////////////////////////////////////// 
////////////////////////////////////////////////////////////////////////////////////////////////////////// 
 

void RCC_Configuration(void)
{
    ErrorStatus errorStatus;
    // Resets the clock configuration to the default reset state
    RCC_DeInit();
    // Enable external crystal (HSE)
    RCC_HSEConfig(RCC_HSE_ON);
    // Wait until HSE ready to use or not
    errorStatus = RCC_WaitForHSEStartUp();

    if (errorStatus == SUCCESS)
    {
        // Configure the PLL for 168MHz SysClk and 48MHz for USB OTG, SDIO
        //RCC_PLLConfig(RCC_PLLSource_HSE, 16/4, 336/4, 2, 7);      //Divisor by 4 because TSL use not stable Quartz
        //RCC_PLLConfig(RCC_PLLSource_HSE, 16/4, 220/2, 2, 7);      //Divisor by 4 because TSL use not stable Quartz
//        RCC_PLLConfig(RCC_PLLSource_HSE, 16, 336, 2, 7);      //Divisor by 4 because TSL use not stable Quartz
//        RCC_PLLConfig(RCC_PLLSource_HSE, 16, 240*2, 2, 15);      //Divisor by 4 because TSL use not stable Quartz
//        RCC_PLLConfig(RCC_PLLSource_HSE, 16, 200*2, 2, 15);      //Divisor by 4 because TSL use not stable Quartz
        RCC_PLLConfig(RCC_PLLSource_HSE, 16, 192*2, 2, 15);      //Divisor by 4 because TSL use not stable Quartz
//        RCC_PLLConfig(RCC_PLLSource_HSE, 16, 250*2, 2, 15);      //Divisor by 4 because TSL use not stable Quartz
//        RCC_PLLConfig(RCC_PLLSource_HSE, 16, 168*2, 2, 15);      //Divisor by 4 because TSL use not stable Quartz
        // Enable PLL
        RCC_PLLCmd(ENABLE);
        // Wait until main PLL clock ready
        while (RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET);

        // Set flash latency
        FLASH_SetLatency(FLASH_Latency_5);    //Maybe need FLASH_Latency_5 ? // I test this value with 50 degress heating ... on 405
        FLASH_PrefetchBufferCmd(ENABLE);
        FLASH_InstructionCacheCmd(ENABLE);    //IORQ clear caching and slowpoke enter in to the Interrupt ... DISABLE for max speed !!!
        FLASH_DataCacheCmd(ENABLE);

        // AHB 168MHz
        RCC_HCLKConfig(RCC_SYSCLK_Div1);
        // APB1 42MHz
        RCC_PCLK1Config(RCC_HCLK_Div4);
        // APB2 84 MHz
        RCC_PCLK2Config(RCC_HCLK_Div2);

        // Set SysClk using PLL
        RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
    }
    else
    {
        // Do something to indicate that error clock configuration
        //while (1); //no wait i will work on the stupid 16mhz ... BRRR
    }

   
}


//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////

void SystemInit(void)
{
//      RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_BKPSRAM, ENABLE);
      RCC_Configuration();
}




void SelectInitGPIO(void)
{
    GpioInit_SWO();
  
//    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
//    GpioInit_TIM1CH2();
//    GpioAFCF_TIM1CH2(GPIO_AF_TIM1); //GPIO_PinAFConfig
    //GpioInit_TIM1CH3();
    //GpioAFCF_TIM1CH3(GPIO_AF_TIM1);
//    GpioInit_DACTEST();
  

      GpioInit_DAC1();
      GpioInit_DAC2();
  
      GpioInit_AY_BDIR(); //GpioInit_PRTB0();
      GpioInit_AY_BC1();  //GpioInit_PRTB1();
      GpioInit_PRTB2();
      GpioInit_PRTB4();
      GpioInit_PRTB5();
      GpioInit_PRTB6();
      GpioInit_PRTB7();
      GpioInit_PRTB8();
      GpioInit_PRTB9();
      GpioInit_PRTB10();
      GpioInit_PRTB11();
      GpioInit_PRTB12();
      GpioInit_PRTB13();
      GpioInit_PRTB14();
      GpioInit_PRTB15();
  
      GpioInit_AY_RESET();
      
}
void Init(void)
{
        RCC_GetClocksFreq(&MPU_ClocksStatus);
//        PCLK1=RCC_ClocksStatus.PCLK1_Frequency;// stm32_GetPCLK1();
//        PCLK2=RCC_ClocksStatus.PCLK2_Frequency;// stm32_GetPCLK2();
        PCLK1_NOP=MPU_ClocksStatus.SYSCLK_Frequency/1000000;
//        TIMER0_PER=stm32_TimerGetReload(0);
//        TIMER1_PER=stm32_TimerGetReload(1);
//        TIMER2_PER=stm32_TimerGetReload(2);
//        TIMER3_PER=stm32_TimerGetReload(3);
//        TIMER4_PER=stm32_TimerGetReload(4);

        SelectInitGPIO();
/*  
        SPI2_Init();
        SPI2_DMA_Init();
        SPI2_GPIO_ON();

        SPI3_Init();
        SPI3_DMA_Init();
        SPI3_GPIO_ON();
  */

  
}





//


