//////////////////////////////////////////////////////////////////////////////////////
// By Rob F. / Entire Group
//////////////////////////////////////////////////////////////////////////////////////

#include "SysType.h"
#include "ChipAY_WS_Process.h"
#include "hardware.h"
#include "interface.h"
#include "ChipAY_Test.h"
#include "ChipAY_WildSound.h"
#include "ChipAY_Interrupt.h"
#include "ChipAY_Hardware.h"
#include "ChipAY_BootFlasher.h"


void wsPoolFlasherMode(void)
{
        //if ( (ayStr.WORK_STATUS & TSL_AYX32_S_DRQ)*0 )
        if ( ayStr.WORK_ERROR == TSL_AYX32_E_DOFLASH )
        {
          chayBootFlashDo();
        }
}

void wsPoolTransMode(void)
{
      u32 d;
      //u8 b;
      switch (ayStr.WORK_TRANS_TYPE)
      {
        case TRANS_MODE_USART_SET_115200: d = 115200; goto LabelDoUartInit;
        case TRANS_MODE_USART_SET_57600:  d =  57600; goto LabelDoUartInit;
        case TRANS_MODE_USART_SET_38400:  d =  38400; goto LabelDoUartInit;
        case TRANS_MODE_USART_SET_19200:  d =  19200; goto LabelDoUartInit;
        case TRANS_MODE_USART_SET_14400:  d =  14400; goto LabelDoUartInit;
        case TRANS_MODE_USART_SET_9600:   d =   9600; goto LabelDoUartInit;
        case TRANS_MODE_USART_SET_4800:   d =   4800;
LabelDoUartInit:
          chipAY_IOConfig(0);
          Uart_RS_Init(d,0x01);
          ayStr.WORK_TRANS_TYPE |= 0x8000;
          break;
        case TRANS_MODE_USART_SET_ZXUNO:
          //GPIO_RS_SetMode(interface_GPIO_OFF);
          GpioInit_USARTZXUNO_TX();
          GpioInit_USARTZXUNO_RX();
          chipAY_IOConfig(1);
          ayStr.WORK_TRANS_TYPE |= 0x8000;
          break;
      }
      if (ayStr.WORK_TRANS_TYPE & 0x8000)
      {
        switch (ayStr.WORK_TRANS_TYPE & TRANS_MODE_USART_MASK)
        {
          case TRANS_MODE_USART_DO_MODE:
            __nop();
            break;
          case TRANS_MODE_USART_DO_ZXUNO:
//            b=ayStr.ay[ayStr.ayn].REG.R[14];
//            USARTZXUNO_TX( (b>>UNO_RSBIT_TX)&1 );
//            b = (b & (~(1<<UNO_RSBIT_RX))) | ((USARTZXUNO_RX()&1)<<UNO_RSBIT_RX);
//            ayStr.ay[ayStr.ayn].REG.R[14] = b;
            break;
        }
      }
}


