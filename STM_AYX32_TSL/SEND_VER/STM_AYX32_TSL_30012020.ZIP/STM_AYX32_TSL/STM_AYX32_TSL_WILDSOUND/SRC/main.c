//////////////////////////////////////////////////////////////////////////////////////
// By Rob F. / Entire Group
//////////////////////////////////////////////////////////////////////////////////////

//#include <string.h>
#include "SysType.h"
#include "hardware.h"
#include "hdinterrupt.h"
#include "TestCase.h"
#include "ChipAY_Main.h"
#include "ChipAY_Hardware.h"
#include "ChipAY_Interrupt.h"
#include "ChipAY_WildSound.h"
#include "process.h"
#include "interface.h"
#include "ChipAY_Test.h"
#include "core_UID.h"
#include "BootFlasherF4.h"
#include "ChipAY.h"

//#include "interface.h"



void RNG_Config(void)
{  
 // Enable RNG clock source
  RCC_AHB2PeriphClockCmd(RCC_AHB2Periph_RNG, ENABLE);
  // RNG Peripheral enable
  RNG_Cmd(ENABLE);
}
///////////////////////////////////////////////////
///////////////////////////////////////////////////
///////////////////////////////////////////////////
#include "stdlib.h"

/*
long alloc_ttl, alloc_max;

void available_alloc (void)
{
  struct __mp__ MTYP *q;

  alloc_ttl = 0;
  alloc_max = 0;

  q = (struct __mp__ MTYP *) &__mp__;
  q = q->next;

  while (q)
  {
    alloc_ttl += q->len;
    if (alloc_max < q->len) allox_max = q->len;
    q = q->next;
  }
}
*/


/*
static uint8_t nrheap[NRHEAP_SIZE];
static uint8_t *nrheap_ptr = nrheap;

// public
uint16_t nrheap_requested = 0;
uint16_t nrheap_num_calls = 0;

uint8_t* nrheap_alloc(uint16_t size)
{
    uint8_t *ptr = nrheap_ptr;

    nrheap_num_calls++;
    nrheap_requested += size;

    if (size > nrheap_free) {
        return (NULL);
    }

    nrheap_ptr  += size;
    nrheap_free -= size;

    return ptr;

}
*/

//#include <minilib.h>

/*
char ExtraHeap[ 0xC00 ] ;

__attribute__( ( used ) ) unsigned __user_heap_extend( int var0, void **base, unsigned requested_size )
{
  unsigned RetVal ;

  if( sizeof( ExtraHeap ) >= requested_size )
  {
    *base = ExtraHeap ;
    RetVal = sizeof( ExtraHeap ) ;
  } else {
    RetVal = 0 ;
  }

  return( RetVal ) ;
}
*/

extern u32 __initial_sp[];
extern u32 __heap_base[];
extern u32 __Vectors[];

extern u32 __ADDR_ram_free[];
extern u32 __ADDR_ccmram_free[];


//extern u32 STACK_SPACE.bss;

//extern unsigned int Image$$ER_ZI$$Limit;
/*
__value_in_regs struct R0_R3
{
  unsigned heap_base, stack_base, heap_limit, stack_limit;
}
__user_initial_stackheap(unsigned int R0, unsigned int SP, unsigned int R2, unsigned int SL)
{
struct R0_R3 config;
extern unsigned int Region$$Table$$Base;//Image$$SRAM$$ZI$$Base;
  config.stack_base = SP;
  config.heap_base = (unsigned int)Region$$Table$$Base;//Image$$SRAM$$ZI$$Base;
  return config;
}
*/

//config.heap_base = (unsigned int) &Image$$ER_ZI$$Limit;




/// @cond HIDDEN_SYMBOLS

extern unsigned int Image$$RW_IRAM1$$ZI$$Limit;
//extern unsigned int Image$$RW_IRAM1$$ZI$$Length;
//extern unsigned int Load$$LR$$RW_IRAM1$$Limit;

//#define dupel   Load$$LR$$LR_IROM1$$Length
//#define dupel   Load$$RW_IRAM1$$RO$$Length
//#define dupel   Load$$RW_IRAM1$$ZI$$Length
#define dupel   Image$$RW_IRAM1$$ZI$$Length


extern unsigned int dupel;


extern unsigned int Image$$RW_IRAM3$$ZI$$Limit;




__value_in_regs struct R0_R3 {unsigned heap_base, stack_base, heap_limit, stack_limit;} 
    __user_setup_stackheap(unsigned int R0, unsigned int SP, unsigned int R2, unsigned int SL)

{
    struct R0_R3 config;


    config.heap_base = (unsigned int)&Image$$RW_IRAM1$$ZI$$Limit;
    config.stack_base = SP;


    return config;
}
/// @endcond HIDDEN_SYMBOLS



void mallocTets(void)
{
#define hepsblk   8
    __nop();
    u32 d;
     Send_RS_String("------------\x0D\x0A");
    /*u32 *p[hepsblk];
    for (u32 n=0; n<hepsblk; n++)
    {
      p[n] = malloc(512-8);
      d = (u32)&((u32 *)p[n])[0];
      Send_RS_HEX(d,8);
      Send_RS_String("\x0D\x0A");
    }
  
    
    for (u32 n=0; n<hepsblk; n++)
    {
      free(p[n]);
    }*/
  
    d = (u32)&__heap_base;
    Send_RS_String("HEAP .... ");
    Send_RS_HEX(d,8);
    Send_RS_String("\x0D\x0A");

    d = (u32)&__ADDR_ram_free;
    Send_RS_String("A_RAM ... ");
    Send_RS_HEX(d,8);
    Send_RS_String("\x0D\x0A");

    d = (u32)&__ADDR_ccmram_free;
    Send_RS_String("A_CCM ... ");
    Send_RS_HEX(d,8);
    Send_RS_String("\x0D\x0A");

    //struct R0_R3 config;
    //config = __user_setup_stackheap(0,0,0,0);
    //config = (u32)&Region$$Table$$Base;
    
    d = (u32)&Image$$RW_IRAM1$$ZI$$Limit;
    Send_RS_String("IRAM1_LIMIT .... ");
    Send_RS_HEX(d,8);
    Send_RS_String("\x0D\x0A");

    d = (u32)&dupel;
    Send_RS_String("IRAM1_?????? ... ");
    Send_RS_HEX(d,8);
    Send_RS_String("\x0D\x0A");

    d = (u32)&Image$$RW_IRAM3$$ZI$$Limit;
    Send_RS_String("IRAM3_LIMIT .... ");
    Send_RS_HEX(d,8);
    Send_RS_String("\x0D\x0A");



    
//    d = STACK_SPACE.bss;


//    u32 d = sizeof( __attribute__((section("ccmram"))) );
  
//    unsigned int addr;
//    addr = __Ram_Loc__;  
  
  
    __nop();
}


void ShowStartInfo(void)
{
    Send_RS_String("\x0D\x0A");
    Send_RS_String("Boot Flasher ...\x0D\x0A");
    Send_RS_String("Enture Group\x0D\x0A");
    {
      Send_RS_String("Flash Size: ");
      Send_RS_DEC(CORE_UID->FlashSizeK*1024);
      Send_RS_String("\x0D\x0A");
      
      Send_RS_String("Device ");
      Send_RS_HEX(CORE_UID->U_ID[0],8);
      Send_RS_Byte(' ');
      Send_RS_HEX(CORE_UID->U_ID[1],8);
      Send_RS_Byte(' ');
      Send_RS_HEX(CORE_UID->U_ID[2],8);
      //05DF2D34 34335746 43033515
      Send_RS_String("\x0D\x0A");
    }
}


int main(void)
{
    if (bflBootCheckNeedFlashing())
    {
      bflBootExtremalExecuteBlockType(BLOCK_TYPES_BOOT_STATIC);
      __nop();
    }
//    MPU_RegionConfig();
//    MPU_ExceptionByDMA_Test();
  
    hdIntSwitchInterruptToRAM();
    Init();
    Uart_RS_Init(115200,0x01);
      
    ShowStartInfo();
  
    mallocTets();
  
    __disable_irq();

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
    ChipAY_ArmInit();
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
    
  
//    InterfaceInit();

    RNG_Config();
  
    chipAY_HardwareInit();
    //tstcasTimerTest();
    //tstcasExternatInterruptTest();
  
  
  //Reset Config
    ChipAY_Init(&ayStr.ay[0]);
    ChipAY_Init(&ayStr.ay[1]);

    chipAY_InterruptConfig();
    
    //TEST_Spi();
    __enable_irq();

    chMain();

}



