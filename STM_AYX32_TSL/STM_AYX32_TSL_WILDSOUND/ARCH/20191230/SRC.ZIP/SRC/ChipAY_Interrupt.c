//////////////////////////////////////////////////////////////////////////////////////
// By Rob F. / Entire Group
//////////////////////////////////////////////////////////////////////////////////////

#include "SysType.h"
#include "ChipAY_Interrupt.h"
#include "ChipAY_Hardware.h"
#include "ChipAY_WildSound.h"
#include "hardware.h"
#include <cstddef>


//R[ 0, 1] - TONE A
//R[ 2, 3] - TONE B
//R[ 4, 5] - TONE C
//R[ 6]    - NOISE
//R[ 7]    - MIX
//R[ 8]    - VOL A
//R[ 9]    - VOL B
//R[10]    - VOL C
//R[11,12] - ENV 
//R[13]    - ENV EFF


// OUT 65533,255    - sl CHIP 0
// OUT 65533,254    - sl CHIP 1
// OUT 65533,3      - wr REG=3
// OUT 49149,34     - wr DTA=34
// IN  65533        - rd DTA 





//TABLE generator for update Set/Clear GPIOB8..15
#define tblTslGen001(v)     (u32)( ((((u32)(v)) & 0xFF) | (((~(u32)(v)) & 0xFF)<<16) ) << 8 )
#define tblTslGen002(v)    tblTslGen001((v)), tblTslGen001((v)+  1)
#define tblTslGen004(v)    tblTslGen002((v)), tblTslGen002((v)+  2)
#define tblTslGen008(v)    tblTslGen004((v)), tblTslGen004((v)+  4)
#define tblTslGen016(v)    tblTslGen008((v)), tblTslGen008((v)+  8)
#define tblTslGen032(v)    tblTslGen016((v)), tblTslGen016((v)+ 16)
#define tblTslGen064(v)    tblTslGen032((v)), tblTslGen032((v)+ 32)
#define tblTslGen128(v)    tblTslGen064((v)), tblTslGen064((v)+ 64)
#define tblTslGen256(v)    tblTslGen128((v)), tblTslGen128((v)+128)
const vu32 outDataForTslPort[256]={
  tblTslGen256(0)
};

//__attribute__((alias("EXTI01_extProc")))
                            //REG par 0=*PER, 1=*SRC, 2=MASK

//u32 asddd __attribute__((alias("&ayStr.ay[0].REG.ST.TONE[0]")));

#define tblADDpar(_per, _aytone, _mask) { [0]=(u32 *)_per                     , \
                                          [1]=(u32 *)(&_aytone)               , \
                                          [2]=(u32 *)_mask                    , \
                                          [3]=(u32 *)0x00000000               , }

vu32 tblNULL=0;
#define tblADDnul()                     { [0]=(u32 *)(&tblNULL)               , \
                                          [1]=(u32 *)(&tblNULL)               , \
                                          [2]=(u32 *)(&tblNULL)               , \
                                          [3]=(u32 *)(&tblNULL)               , }
//For fast access to perriod update
const vu32 *tbl_AYREGPER_update[32][4]={
   [0x00] = tblADDpar(AY0TONEAwp_PSC, ayStr.ay[0].REG.ST.TONE[0], 0x0FFF),
   [0x01] = tblADDpar(AY0TONEAwp_PSC, ayStr.ay[0].REG.ST.TONE[0], 0x0FFF),
   [0x02] = tblADDpar(AY0TONEBwp_PSC, ayStr.ay[0].REG.ST.TONE[1], 0x0FFF),
   [0x03] = tblADDpar(AY0TONEBwp_PSC, ayStr.ay[0].REG.ST.TONE[1], 0x0FFF),
   [0x04] = tblADDpar(AY0TONECwp_PSC, ayStr.ay[0].REG.ST.TONE[2], 0x0FFF),
   [0x05] = tblADDpar(AY0TONECwp_PSC, ayStr.ay[0].REG.ST.TONE[2], 0x0FFF),
   [0x06] = tblADDpar(AY0NOIwp_PSC,   ayStr.ay[0].REG.ST.NOISE  , 0x001F),
   [0x07] = tblADDnul(),
   [0x08] = tblADDnul(),
   [0x09] = tblADDnul(),
   [0x0A] = tblADDnul(),
   [0x0B] = tblADDpar(AY0ENVwp_PSC,   ayStr.ay[0].REG.ST.ENV    , 0xFFFF),
   [0x0C] = tblADDpar(AY0ENVwp_PSC,   ayStr.ay[0].REG.ST.ENV    , 0xFFFF),
   [0x0D] = tblADDpar(AY0ENVwp_CNT,   ayStr.ay[0].REG.ST.ENV    , 0x0000),
   [0x0E] = tblADDnul(),
   [0x0F] = tblADDnul(),
   [0x10] = tblADDpar(AY1TONEAwp_PSC, ayStr.ay[1].REG.ST.TONE[0], 0x0FFF),
   [0x11] = tblADDpar(AY1TONEAwp_PSC, ayStr.ay[1].REG.ST.TONE[0], 0x0FFF),
   [0x12] = tblADDpar(AY1TONEBwp_PSC, ayStr.ay[1].REG.ST.TONE[1], 0x0FFF),
   [0x13] = tblADDpar(AY1TONEBwp_PSC, ayStr.ay[1].REG.ST.TONE[1], 0x0FFF),
   [0x14] = tblADDpar(AY1TONECwp_PSC, ayStr.ay[1].REG.ST.TONE[2], 0x0FFF),
   [0x15] = tblADDpar(AY1TONECwp_PSC, ayStr.ay[1].REG.ST.TONE[2], 0x0FFF),
   [0x16] = tblADDpar(AY1NOIwp_PSC,   ayStr.ay[1].REG.ST.NOISE  , 0x001F),
   [0x17] = tblADDnul(),
   [0x18] = tblADDnul(),
   [0x19] = tblADDnul(),
   [0x1A] = tblADDnul(),
   [0x1B] = tblADDpar(AY1ENVwp_PSC,   ayStr.ay[1].REG.ST.ENV    , 0xFFFF),
   [0x1C] = tblADDpar(AY1ENVwp_PSC,   ayStr.ay[1].REG.ST.ENV    , 0xFFFF),
   [0x1D] = tblADDpar(AY1ENVwp_CNT,   ayStr.ay[1].REG.ST.ENV    , 0x0000),
   [0x1E] = tblADDnul(),
   [0x1F] = tblADDnul(),
};


//const void (*tbl_AYREGPER_proc[32])(void);

void asd(void)
{
}

//
//void (*tbl_AYREGPER_proc[1])(void) ={asd};
//

#define tonOFS     (-1)
#define envOFS     (-1)

static __forceinline u16 prcAYtneMAX(u16 vvv)
{
    const u16 vv = vvv & 0x0FFF;
    const u16 v = vv;// ? vv : 1;
    u16 t = v + tonOFS;
    return (t & 0x8000) ? 0 : t;
}

static __forceinline u16 prcAYenvMAX(u16 vvv)
{
    const u16 vv = vvv;
    const u16 v = vv;// ? vv : 1;
    u32 t = v + envOFS;
    return (t & 0xFFFF0000) ? 0 : t;
}

//#define prcAYnoiMAX(_v)     ((_v) & 0x1F)
static __forceinline u16 prcAYnoiMAX(u8 v)
{
    const u8 vv=v & 0x1F;
    return vv ? vv : 1;
}

//typedef void(*)(void) tVoidProc;
void prcAY0prcR00(void) { AYxPERcur(AY0TONEA) = prcAYtneMAX(ayStr.ay[0].REG.ST.TONE[0]);        }
void prcAY0prcR02(void) { AYxPERcur(AY0TONEB) = prcAYtneMAX(ayStr.ay[0].REG.ST.TONE[1]);        }
void prcAY0prcR04(void) { AYxPERcur(AY0TONEC) = prcAYtneMAX(ayStr.ay[0].REG.ST.TONE[2]);        }
void prcAY0prcR06(void) { AYxPERupd(AY0NOI,     prcAYnoiMAX(ayStr.ay[0].REG.ST.NOISE)       );  }
void prcAY0prcR0B(void) { AYxPERupd(AY0ENV,     prcAYenvMAX(ayStr.ay[0].REG.ST.ENV  )       );  }
void prcAY0prcR0D(void) { AYxCNTcur(AY0ENV)   = 0x0000                                       ;  }
void prcAY0prcR18(void) { AYxPWMupd(AY0TONEA,               ayStr.ay[0].REG.ST.PWM[0]       );  }
void prcAY0prcR19(void) { AYxPWMupd(AY0TONEB,               ayStr.ay[0].REG.ST.PWM[1]       );  }
void prcAY0prcR1A(void) { AYxPWMupd(AY0TONEC,               ayStr.ay[0].REG.ST.PWM[2]       );  }


void prcAY1prcR00(void) { AYxPERcur(AY1TONEA) = prcAYtneMAX(ayStr.ay[1].REG.ST.TONE[0]);        }
void prcAY1prcR02(void) { AYxPERcur(AY1TONEB) = prcAYtneMAX(ayStr.ay[1].REG.ST.TONE[1]);        }
void prcAY1prcR04(void) { AYxPERcur(AY1TONEC) = prcAYtneMAX(ayStr.ay[1].REG.ST.TONE[2]);        }
void prcAY1prcR06(void) { AYxPERupd(AY1NOI,     prcAYnoiMAX(ayStr.ay[1].REG.ST.NOISE)       );  }
void prcAY1prcR0B(void) { AYxPERupd(AY1ENV,     prcAYenvMAX(ayStr.ay[1].REG.ST.ENV  )       );  }
void prcAY1prcR0D(void) { AYxCNTcur(AY1ENV)   = 0x0000                                       ;  }
void prcAY1prcR18(void) { AYxPWMupd(AY1TONEA,               ayStr.ay[1].REG.ST.PWM[0]       );  }
void prcAY1prcR19(void) { AYxPWMupd(AY1TONEB,               ayStr.ay[1].REG.ST.PWM[1]       );  }
void prcAY1prcR1A(void) { AYxPWMupd(AY1TONEC,               ayStr.ay[1].REG.ST.PWM[2]       );  }

void prcAYprcNULL(void) {}

  
const tVoidProc tbl_AYREGPER_proc[64]={
  [0x00] = prcAY0prcR00,
  [0x01] = prcAY0prcR00,
  [0x02] = prcAY0prcR02,
  [0x03] = prcAY0prcR02,
  [0x04] = prcAY0prcR04,
  [0x05] = prcAY0prcR04,
  [0x06] = prcAY0prcR06,
  [0x07] = prcAYprcNULL,
  [0x08] = prcAYprcNULL,
  [0x09] = prcAYprcNULL,
  [0x0A] = prcAYprcNULL,
  [0x0B] = prcAY0prcR0B,
  [0x0C] = prcAY0prcR0B,
  [0x0D] = prcAY0prcR0D,
  [0x0E] = prcAYprcNULL,
  [0x0F] = prcAYprcNULL,
  
  [0x10] = prcAYprcNULL,
  [0x11] = prcAYprcNULL,
  [0x12] = prcAYprcNULL,
  [0x13] = prcAYprcNULL,
  [0x14] = prcAYprcNULL,
  [0x15] = prcAYprcNULL,
  [0x16] = prcAYprcNULL,
  [0x17] = prcAYprcNULL,
  [0x18] = prcAY0prcR18,
  [0x19] = prcAY0prcR19,
  [0x1A] = prcAY0prcR1A,
  [0x1B] = prcAYprcNULL,
  [0x1C] = prcAYprcNULL,
  [0x1D] = prcAYprcNULL,
  [0x1E] = prcAYprcNULL,
  [0x1F] = prcAYprcNULL,
////
  [0x20] = prcAY1prcR00,
  [0x21] = prcAY1prcR00,
  [0x22] = prcAY1prcR02,
  [0x23] = prcAY1prcR02,
  [0x24] = prcAY1prcR04,
  [0x25] = prcAY1prcR04,
  [0x26] = prcAY1prcR06,
  [0x27] = prcAYprcNULL,
  [0x28] = prcAYprcNULL,
  [0x29] = prcAYprcNULL,
  [0x2A] = prcAYprcNULL,
  [0x2B] = prcAY1prcR0B,
  [0x2C] = prcAY1prcR0B,
  [0x2D] = prcAY1prcR0D,
  [0x2E] = prcAYprcNULL,
  [0x2F] = prcAYprcNULL,
  
  [0x30] = prcAYprcNULL,
  [0x31] = prcAYprcNULL,
  [0x32] = prcAYprcNULL,
  [0x33] = prcAYprcNULL,
  [0x34] = prcAYprcNULL,
  [0x35] = prcAYprcNULL,
  [0x36] = prcAYprcNULL,
  [0x37] = prcAYprcNULL,
  [0x38] = prcAY1prcR18,
  [0x39] = prcAY1prcR19,
  [0x3A] = prcAY1prcR1A,
  [0x3B] = prcAYprcNULL,
  [0x3C] = prcAYprcNULL,
  [0x3D] = prcAYprcNULL,
  [0x3E] = prcAYprcNULL,
  [0x3F] = prcAYprcNULL,
};


#pragma push

//6876

//#pragma arm section code="RAMCODE"
/*
void EXT_DoAyReneratorUpdate(u8 ayn, u8 adL)
{
      tbl_AYREGPER_proc[(adL | (ayn<<4)) & 0x1F]();
}
*/

// REG      BIT  Description
// 00       8    TONE A LO
// 01       4    TONE A HI
// 02       8    TONE B LO
// 03       4    TONE B HI
// 04       8    TONE C LO
// 05       4    TONE C HI
// 06       5    NOISE
// 07       6    MASK
// 08       5    VOL A
// 09       5    VOL B
// 0A       5    VOL C
// 0B       8    ENV LO
// 0C       8    ENV HI
// 0D       5    ENV MODE
// 0E       8    PORT A
// 0F       8    PORT B
// 10       8    TONE A LO PHASE
// 11       4    TONE A HI PHASE
// 12       8    TONE B LO PHASE
// 13       4    TONE B HI PHASE
// 14       8    TONE C LO PHASE
// 15       4    TONE C HI PHASE
// 16            NONE
// 17            NONE
// 18       8    PWM A (PHASE FIX)
// 19       8    PWM A (PHASE FIX)
// 1A       8    PWM A (PHASE FIX)
// 1B            NONE
// 1C            NONE
// 1D            NONE
// 1E            NONE
// 1F            NONE
// F0       8    Unlock String 
//                IN:"Wild Sound Enable ",WORK_CMD,0x00
//               OUT:0xDF (UNLOCKED)

u8 EXT_DoAyBusGetUpdateDataLatch(void)
{
      return 0;
}


//__attribute__((section("RAMCODE")))
void EXT_DoAyBusReg(void)
{
          u8 ayn = ayStr.ayn;
          u8 adL = ayStr.ay[ayn].adr & 0x0F;
          u8 adH = ayStr.ay[ayn].adr >> 4;
    const u8 bdt = ayStr.bus>>8;
    switch ( ayStr.bus & BDIRBC_mask )
    {
      case BDIRBC_READ:
        break;
      case BDIRBC_WRITE_ADDR:
        ayStr.ay[ayn].adr = bdt;
        adL = bdt & 0x0F;
        adH = bdt >> 4;
        switch (adH)
        {
          case 0xF:
            switch (adL)
            {
              case 0xE:
                ayStr.ayn = 1;
                break;
              case 0xF:
                ayStr.ayn = 0;
                break;
            }
            break;
        }
        ayn = ayStr.ayn;
        ayStr.dta = ayStr.ay[ayn].REG.R[adL];
        break;
      case BDIRBC_WRITE_DATA:
        ayStr.dta = 0xFF;
        switch (adH)
        {
          case 0x0:
            ayStr.ay[ayn].REG.R[adL+0x00] = bdt;
            EXT_DoAyReneratorUpdate(ayn, adL+0x00);
            ayStr.dta = ayStr.ay[ayn].REG.R[adL+0x00];
            break;
          case 0x1:
            ayStr.ay[ayn].REG.R[adL+0x10] = bdt;
            EXT_DoAyReneratorUpdate(ayn, adL+0x10);
            ayStr.dta = ayStr.ay[ayn].REG.R[adL+0x10];
            break;
        }
        
        break;
    }
    GPIO_Port(GPIOB) = outDataForTslPort[ (u8)ayStr.dta ];
    
}

//__attribute__((section("RAMCODE")))
__asm void EXTI01_extProc(void) __irq
{
    //CPSID     I
    PUSH      {R0-R3,R4-R5}
    LDR       R0, = __cpp( SWOwp_port )//__cpp(GPIOB_BASE)

   //Read GPIOB
    LDR       R2, [R0, #__cpp(offsetof(GPIO_TypeDef, IDR))]
    LDR       R1, =__cpp(&ayStr)
    STRH      R2, [R1, #__cpp(offsetof(tAY_Struct, bus))]   //16 bit !!!
   //Old value of gpioMODE
    LDR       R4, [R0, #__cpp(offsetof(GPIO_TypeDef, MODER))]
  
    MOV       R3, #0x5555       //MODE OUT
lRD
    AND       R2, R2, #__cpp(BDIRBC_mask)
    CMP       R2, #__cpp(BDIRBC_READ)
   //Out Mode
    STRHEQ    R3, [R0, #__cpp(offsetof(GPIO_TypeDef, MODER))+2]
    LDREQ     R2, [R0, #__cpp(offsetof(GPIO_TypeDef, IDR))]
    BEQ       lRD
   //In Mode
    STR       R4, [R0, #__cpp(offsetof(GPIO_TypeDef, MODER))]

     MOV       R2, #__cpp(dH_PORT_BSSR((SWOwp_pin),(0)))         //Get SetResetBit
     STR       R2, [R0, #__cpp(offsetof(GPIO_TypeDef, BSRRL))]   //SWO = "0"
    
    LDR       R1, = __cpp(EXTI_BASE)
    MOV       R2, # __cpp(EXTI_Line0 | EXTI_Line1)
    STR       R2, [R1, #__cpp(offsetof(EXTI_TypeDef, PR))]
    //NVIC->ICPR[((u32)(IRQn) >> 5)] = (1 << ((u32)(IRQn) & 0x1F));
    LDR       R1, = __cpp(NVIC_BASE) + __cpp(offsetof(NVIC_Type, ICPR))
    LDR       R2, = __cpp((1 << ((u32)(EXTI0_IRQn) & 0x1F)) | (1 << ((u32)(EXTI1_IRQn) & 0x1F)))
    STR       R2, [R1, #__cpp((u32)(EXTI0_IRQn)>>5)]
    
    
    PUSH      {R0,LR}
    BL        __cpp(EXT_DoAyBusReg)
    POP       {R0,LR}
    
//    LDR       R0, = __cpp( SWOwp_port )
     MOV       R2, # __cpp(dH_PORT_BSSR((SWOwp_pin),(1)))        //Get SetResetBit
     STR       R2, [R0, #__cpp(offsetof(GPIO_TypeDef, BSRRL))]   //SWO = "1"

    
    POP       {R0-R3,R4-R5}
    //CPSIE     I
    BX        LR
    ALIGN
}

void EXTI0_IRQHandler(void) __attribute__((alias("EXTI01_extProc")));
void EXTI1_IRQHandler(void) __attribute__((alias("EXTI01_extProc")));

#pragma pop

void EXTI2_IRQHandler(void)
{
    //TIM_ClearITPendingBit(TIM7, TIM_IT_Update);
  
  //NVIC
    EXTI_ClearITPendingBit(EXTI_Line2);//  EXTI->PR = EXTI_Line2;
    NVIC_ClearPendingIRQ(EXTI2_IRQn);
  
    while ( AY_RESET() ==0) __nop();
    //for (u32 n=0; n<100000; n++) __nop();
    NVIC_SystemReset();
}


void EXTI_SetITStatus(uint32_t EXTI_Line)
{
    EXTI->SWIER = EXTI_Line;
}

void chipAY_InterruptConfig(void)
{
  EXTI_InitTypeDef EXTI_InitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;
  

    //vectorTable_RAM[16+EXTI0_IRQn] = vectorTable_RAM[16+EXTI1_IRQn] = (u32)EXTI01_extProc;

  
  
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);

    // Connect EXTI Line to GPIO Pin 
    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource0);
    // Connect EXTI Line to GPIO Pin 
    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource1);
    // Configure Button EXTI line
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;//EXTI_Trigger_Rising;  
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;

    // Enable and set EXTI Interrupt to the lowest priority 
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  
    EXTI_InitStructure.EXTI_Line = EXTI_Line0;
    EXTI_Init(&EXTI_InitStructure);
    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
    NVIC_Init(&NVIC_InitStructure);

    EXTI_InitStructure.EXTI_Line = EXTI_Line1;
    EXTI_Init(&EXTI_InitStructure);
    NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;
    NVIC_Init(&NVIC_InitStructure);

    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_Line = EXTI_Line2;
    EXTI_Init(&EXTI_InitStructure);
    NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;
    NVIC_Init(&NVIC_InitStructure);


//    EXTI_SetITStatus(EXTI_Line0);  
//    EXTI_SetITStatus(EXTI_Line1);  
}
