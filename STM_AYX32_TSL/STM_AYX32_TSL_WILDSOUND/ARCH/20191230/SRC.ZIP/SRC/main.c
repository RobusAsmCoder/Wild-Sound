//////////////////////////////////////////////////////////////////////////////////////
// By Rob F. / Entire Group
//////////////////////////////////////////////////////////////////////////////////////

//#include <string.h>
#include "SysType.h"
#include "hardware.h"
#include "hdinterrupt.h"
#include "TestCase.h"
#include "ChipAY_Hardware.h"
#include "ChipAY_Interrupt.h"
#include "ChipAY_WildSound.h"
#include "process.h"

//#include "interface.h"


process_alloc(process_main,        1, 4, 1);
process_alloc(process_aydac,       1, 4, 1);

void RNG_Config(void)
{  
 // Enable RNG clock source
  RCC_AHB2PeriphClockCmd(RCC_AHB2Periph_RNG, ENABLE);
  // RNG Peripheral enable
  RNG_Cmd(ENABLE);
}
///////////////////////////////////////////////////
///////////////////////////////////////////////////
///////////////////////////////////////////////////

int main(void)
{
    //hdIntSwitchInterruptToRAM();
    Init();
      
    __disable_irq();
  
//    InterfaceInit();

    RNG_Config();
  
    chipAY_HardwareInit();
    tstcasTimerTest();
    //tstcasExternatInterruptTest();
  
  
  //Reset Config
    ChipAY_Init(&ayStr.ay[0]);
    ChipAY_Init(&ayStr.ay[1]);

    chipAY_InterruptConfig();

    __enable_irq();
  
    ListProcADD(&process_main,        proc_LNG_Main       | ProcSys_LOOP_INFINITE);
    ListProcADD(&process_aydac,       proc_LNG_AYDAC      | ProcSys_LOOP_INFINITE);  
    
    while(1)
    {
      DoProc(&process_aydac,  proc_NOP);
      DoProc(&process_main,   proc_NOP);      
    }

}



