//////////////////////////////////////////////////////////////////////////////////////
// By Rob F. / Entire Group
//////////////////////////////////////////////////////////////////////////////////////

#ifndef __CHIPAY_INTERRUPT_H
#define __CHIPAY_INTERRUPT_H


#include "SysType.h"
#include "hardware.h"

//BDIR   BC1
// 0      0    - Z
// 0      1    - Read from ME
// 1      0    - Write to ME data
// 1      1    - Write to ME addr
enum {
  BDIRBC_mask       = (s32)(AY_BDIRwp_bit | AY_BC1wp_bit),
  BDIRBC_TRISTATE   = (s32)(0             | 0           ),
  BDIRBC_READ       = (s32)(0             | AY_BC1wp_bit),
  BDIRBC_WRITE_DATA = (s32)(AY_BDIRwp_bit | 0           ),
  BDIRBC_WRITE_ADDR = (s32)(AY_BDIRwp_bit | AY_BC1wp_bit),
};

typedef void (*tVoidProc)(void);

extern const tVoidProc tbl_AYREGPER_proc[64];

#define EXT_DoAyReneratorUpdate(ayn, adL)     tbl_AYREGPER_proc[((adL) | ((ayn)<<5)) & 0x3F]()
//extern void EXT_DoAyReneratorUpdate(u8 ayn, u8 adL);

extern void chipAY_InterruptConfig(void);

#endif
