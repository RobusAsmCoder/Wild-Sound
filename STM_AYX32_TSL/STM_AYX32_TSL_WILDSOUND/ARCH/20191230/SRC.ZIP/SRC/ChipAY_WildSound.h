//////////////////////////////////////////////////////////////////////////////////////
// By Rob F. / Entire Group
//////////////////////////////////////////////////////////////////////////////////////

#ifndef __CHIPAY_WILDSOUND_H
#define __CHIPAY_WILDSOUND_H

#include "SysType.h"

//#define AyFreqCLK         ((u32)(1750000))      //HZ clocking for AY chip
#define AyFreqCLK         ((u32)(1774400))      //HZ clocking for AY chip
#define AyFreqSND         ((u32)(AyFreqCLK/16))        //HZ frquency for DAC

#define AyFreq            ((u32)(AyFreqCLK/1))  //HZ real clock for AY div 8

#pragma push
#pragma pack(1)


typedef struct {
  u8   TA:1;
  u8   TB:1;
  u8   TC:1;
  u8   NA:1;
  u8   NB:1;
  u8   NC:1;
  u8  FRE:2;
}tStructMIXER;


typedef struct {
          u16 TONE[3];        //Tone A,B,C [0..4095]
           u8 NOISE;          //Noise Value [0..31]
 tStructMIXER MIXER;          //Mixer BIT(00NNNTTT)
           u8 VOL[3];         //Vol A,B,C
          u16 ENV;            //Enveloupment Value
           u8 ENVEFF;         //Enveloupment Effect
           u8 IO[2];          //Bidirectional Data X,Y
  
          u16 PHASE[3];       //Phase A,B,C [0..4095]
           u8  :8;
           u8  :8;
           u8 PWM[3];
          u16  :16;
           u8  :8;
           u8  :8;
           u8  :8;
}tStructAY;

typedef union {
      tStructAY   ST;
             u8   R[64];
}tRegAY;

typedef struct {
 tRegAY REG;
    u32 Freq;
    u16 adr;
}tChipAY;


typedef struct{
  u16      bus;       //Bus in latch (GPIOB)
  u16      dta;       //Bus out data
  u16      ayn;       //Selected AY
  tChipAY  ay[2];
  u8       WORK_MODE;
  u8       WORK_CMD;
} tAY_Struct;


#pragma pop


extern tAY_Struct ayStr;

extern void ChipAY_Init(tChipAY *AY);
extern u32 ChipAY_Mixer(tAY_Struct *ays);


#endif
