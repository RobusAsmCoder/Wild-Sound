//////////////////////////////////////////////////////////////////////////////////////
// By Rob F. / Entire Group
//////////////////////////////////////////////////////////////////////////////////////

#ifndef __HARDWARE_H
#define __HARDWARE_H


#include "SysType.h"
#include "globaldata.h"
#include "hdtimers.h"
/////////////////////////////////////////////////////////////////////////////
// Sys Define
/////////////////////////////////////////////////////////////////////////////
#define dH_BITV(_p_, _v_)     ((u32)(_v_)<<(_p_))
#define dH_BIT(_p_)           dH_BITV((_p_), 1)
#define dH_PORT_BSSR(_p_, _v_)  dH_BITV(_p_, _v_) | dH_BIT((_p_) | 16)

#define dH_PORT_BSSR_R(_p_)  dH_BIT((_p_) | 16)
#define dH_PORT_BSSR_S(_p_)  dH_BIT((_p_))
#define dH_PORT_CFG_MD(_name_, _p_, _v_)  _name_ = (_name_ & (~( 0xF<<(4*(_p_) ))) ) | ((u32)(_v_)<<(4*(_p_)))

#define dH_SPI_REG_CR(_spi, _spi_CPOL, _spi_CPHA, _spi_FIRBIT, _spi_NSS, _spi_BAUD, _spi_DSIZE )       _spi->CR1 = (_spi->CR1 & (~(SPI_CPOL_High | SPI_CPHA_2Edge | SPI_FirstBit_LSB | SPI_NSS_Soft | SPI_BaudRatePrescaler_256 | SPI_DataSize_16b ))) | (_spi_CPOL | _spi_CPHA | _spi_FIRBIT | _spi_NSS | _spi_BAUD | _spi_DSIZE)

/////////////////////////////////////////////////////////////////////////////
// Hard Ver 1
/////////////////////////////////////////////////////////////////////////////



/*
//#define 
#define LCD_port            GPIOB
#define LCD_A0_pin          0
#define LCD_A0_bit          dH_BIT(LCD_A0_pin)
#define LCD_RES_pin         1
#define LCD_RES_bit         dH_BIT(LCD_RES_pin)

*/

////////////////////////////////////////////////////////////////////////////////
#define SPI_DMA_CCR(_val_)    (DMA_M2M_Disable | DMA_Priority_VeryHigh | DMA_MemoryDataSize_Byte | DMA_PeripheralDataSize_Byte | DMA_PeripheralInc_Disable | DMA_Mode_Normal | _val_)
#define DmaMemSel(_MemInc)      (_MemInc==0 ? DMA_MemoryInc_Disable : DMA_MemoryInc_Enable)
////////////////////////////////////////////////////////////////////////////////
//SPI0 CONFIG
////////////////////////////////////////////////////////////////////////////////
#define SPI0_CFG_DSIZE      SPI_DataSize_8b
#define SPI0_CFG_CPOL       SPI_CPOL_Low
#define SPI0_CFG_CPHA       SPI_CPHA_1Edge
#define SPI0_CFG_NSS        SPI_NSS_Soft
#define SPI0_CFG_BAUD       SPI_BaudRatePrescaler_4
#define SPI0_CFG_FIRSTBIT   SPI_FirstBit_MSB

//SPI0 TOOLS
//#define SPI0_NSS(_val_)     if (SPI0_AB_SEL) {GPIOA->BSRR = dH_PORT_BSSR(15,(_val_));} else {GPIOA->BSRR = dH_PORT_BSSR(4,(_val_));}
#define SPI0_NSS(_val_)     GPIOA->BSRR = dH_PORT_BSSR(4,(_val_))

#define ON_SPI1_Ax              dH_PORT_CFG_MD(GPIOB->CRL, 3, 3 | (0<<2));                              \
                                SPI1->CR1 |=  SPI_CPOL_High;                                            \
                                AFIO->MAPR = (AFIO->MAPR & (~GPIO_Remap_SPI1)) | 0x07000000;            \
                                dH_PORT_CFG_MD(GPIOA->CRL, 5, 3 | (2<<2))

#define ON_SPI1_Bx              dH_PORT_CFG_MD(GPIOA->CRL, 5, 3 | (0<<2));                              \
                                SPI1->CR1 &= ~SPI_CPOL_High;                                            \
                                AFIO->MAPR |=  GPIO_Remap_SPI1 | 0x07000000;                            \
                                dH_PORT_CFG_MD(GPIOB->CRL, 3, 3 | (2<<2))

extern u8 SPI0_AB_SEL;

#ifdef SPI0_CFG_DSIZE
__inline void ON_SPI0_ACTIVE(void)
{
      dH_PORT_CFG_MD(GPIOB->CRL, 3, 3 | (0<<2));    //PB3 = IN + PULLING
      dH_SPI_REG_CR(SPI1, SPI0_CFG_CPOL, SPI0_CFG_CPHA, SPI0_CFG_FIRSTBIT, SPI0_CFG_NSS, SPI0_CFG_BAUD, SPI0_CFG_DSIZE);
      AFIO->MAPR = (AFIO->MAPR & (~GPIO_Remap_SPI1)) | 0x07000000;
      dH_PORT_CFG_MD(GPIOA->CRL, 5, 3 | (2<<2));    //PA5 = OUTAF + PUSH PULL
      SPI0_AB_SEL=0;
}
#endif
#ifdef SPI1_CFG_DSIZE
__inline void ON_SPI1_ACTIVE(void)
{
      dH_PORT_CFG_MD(GPIOA->CRL, 5, 3 | (0<<2));    //PA5 = IN + PULLING
//      SPI1->CR1 &= ~SPI_CPOL_High;     //CPOL = 0
      dH_SPI_REG_CR(SPI1, SPI1_CFG_CPOL, SPI1_CFG_CPHA, SPI1_CFG_FIRSTBIT, SPI1_CFG_NSS, SPI1_CFG_BAUD, SPI1_CFG_DSIZE);
      AFIO->MAPR |=  GPIO_Remap_SPI1 | 0x07000000;
      dH_PORT_CFG_MD(GPIOB->CRL, 3, 3 | (2<<2));    //PB3 = OUTAF + PUSH PULL
      SPI0_AB_SEL=1;
}
#endif
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
//SPI2 CONFIG
////////////////////////////////////////////////////////////////////////////////
#define SPI2_CFG_DSIZE      SPI_DataSize_8b
#define SPI2_CFG_CPOL       SPI_CPOL_Low
#define SPI2_CFG_CPHA       SPI_CPHA_1Edge
#define SPI2_CFG_NSS        SPI_NSS_Soft
#define SPI2_CFG_BAUD       SPI_BaudRatePrescaler_2
#define SPI2_CFG_FIRSTBIT   SPI_FirstBit_MSB

#define SPI2_NSS(_val_)     GPIOB->BSRR = dH_PORT_BSSR(12,(_val_))

////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//SPI3 CONFIG = SPI1 with ALTERNATE Function
////////////////////////////////////////////////////////////////////////////////
#define SPI3_CFG_DSIZE      SPI_DataSize_8b
#define SPI3_CFG_CPOL       SPI_CPOL_High
#define SPI3_CFG_CPHA       SPI_CPHA_2Edge
#define SPI3_CFG_NSS        SPI_NSS_Soft
#define SPI3_CFG_BAUD       SPI_BaudRatePrescaler_32
#define SPI3_CFG_FIRSTBIT   SPI_FirstBit_MSB

#define SPI3_NSSAport         GPIOA
#define SPI3_NSSAwp_pin       15
#define SPI3_NSSAwp_bit       dH_BIT(SPI3_NSSAwp_pin)
#define SPI3_NSSA(_val_)      SPI3_NSSAport->BSRR = dH_PORT_BSSR(SPI3_NSSAwp_pin,(_val_))

#define SPI3_NSSBport         GPIOC
#define SPI3_NSSBwp_pin       7
#define SPI3_NSSBwp_bit       dH_BIT(SPI3_NSSBwp_pin)
#define SPI3_NSSB(_val_)      SPI3_NSSBport->BSRR = dH_PORT_BSSR(SPI3_NSSBwp_pin,(_val_))

#define SPI3_DMA_IsDisable()    (DMA2_Channel2->CPAR==0)
#define SPI3_DMA_IsEnable()     (DMA2_Channel2->CPAR!=0)
#define SPI3_DMA_SetUp(_TX_MemAdr, _RX_MemAdr, _Size, _TX_MemInc, _RX_MemInc)                 \
  DMA2_Channel2->CNDTR = _Size;                                                               \
  DMA2_Channel2->CMAR  = (u32)(_TX_MemAdr);                                                   \
  DMA2_Channel2->CCR   = SPI_DMA_CCR(DmaMemSel(_TX_MemInc) | DMA_DIR_PeripheralDST);          \
  DMA2_Channel1->CNDTR = _Size;                                                               \
  DMA2_Channel1->CMAR  = (u32)(_RX_MemAdr);                                                   \
  DMA2_Channel1->CCR   = SPI_DMA_CCR(DmaMemSel(_RX_MemInc) | DMA_DIR_PeripheralSRC);
#define SPI3_DMA_FLAG()         ((DMA2_FLAG_TC2 | DMA2_FLAG_TC1) & 0x0FFFFFFF)

#define SPI3_DMA_Start()                                                                      \
  SPI3->CR2 |= (SPI_I2S_DMAReq_Rx | SPI_I2S_DMAReq_Tx);                                       \
  DMA2_Channel1->CCR |= 0x00000001;                                                           \
  DMA2_Channel2->CCR |= 0x00000001;
#define SPI3_DMA_IsBusy()       ((DMA2->ISR & SPI3_DMA_FLAG())!=SPI3_DMA_FLAG())
#define SPI3_DMA_End()                                                                        \
  DMA2->IFCR = SPI3_DMA_FLAG();                                                               \
  DMA2_Channel1->CCR &=~0x00000001;                                                           \
  DMA2_Channel2->CCR &=~0x00000001;                                                           \
  SPI3->CR2 &=~(SPI_I2S_DMAReq_Rx | SPI_I2S_DMAReq_Tx);

////////////////////////////////////////////////////////////////////////////////

/*
//FLASH CONFIG
#define FLASH_port          GPIOB
#define FLASH_wp_pin        5
#define FLASH_wp_bit        dH_BIT(FLASH_wp_pin)
#define Flash_WP(_val_)     FLASH_port->BSRR = dH_PORT_BSSR(FLASH_wp_pin,(_val_))


//LCD CONFIG
#define LCD_A0(_val_)        LCD_port->BSRR = dH_PORT_BSSR(LCD_A0_pin,_val_)
#define LCD_RES(_val_)       LCD_port->BSRR = dH_PORT_BSSR(LCD_RES_pin,_val_)
*/

////////////////////////////////////////////////////////////////////////////////
//KEYS
////////////////////////////////////////////////////////////////////////////////
#define KEY_port          GPIOA
#define KEY_0_pin         0
#define KEY_0_bit         dH_BIT(KEY_0_pin)

#define KEY0()            (KEY_port->IDR & KEY_0_bit)

//(KEY_port->IDR & (1<<KEY_0_pin))


////////////////////////////////////////////////////////////////////////////////
//LED
////////////////////////////////////////////////////////////////////////////////
/*

#define LEDA_port         GPIOC
#define LEDA_R_pin        14
#define LEDA_R_bit        dH_BIT(LEDA_R_pin)
#define LEDA_G_pin        13
#define LEDA_G_bit        dH_BIT(LEDA_G_pin)
#define LEDAR(_val_)      LEDA_port->BSRR = dH_PORT_BSSR(LEDA_R_pin,(_val_))
#define LEDAG(_val_)      LEDA_port->BSRR = dH_PORT_BSSR(LEDA_G_pin,(_val_))

#define LEDB_port         GPIOA
#define LEDB_R_pin        3
#define LEDB_R_bit        dH_BIT(LEDB_R_pin)
#define LEDB_G_pin        2
#define LEDB_G_bit        dH_BIT(LEDB_G_pin)
#define LEDBR(_val_)      LEDB_port->BSRR = dH_PORT_BSSR(LEDB_R_pin,(_val_))
#define LEDBG(_val_)      LEDB_port->BSRR = dH_PORT_BSSR(LEDB_G_pin,(_val_))

#define LEDC_port         GPIOB
#define LEDC_R_pin        11
#define LEDC_R_bit        dH_BIT(LEDC_R_pin)
#define LEDC_G_pin        10
#define LEDC_G_bit        dH_BIT(LEDC_G_pin)
#define LEDCR(_val_)      LEDC_port->BSRR = dH_PORT_BSSR(LEDC_R_pin,(_val_))
#define LEDCG(_val_)      LEDC_port->BSRR = dH_PORT_BSSR(LEDC_G_pin,(_val_))
*/



extern u32 TERMO_VCC_MEASURE(void);
/*
////////////////////////////////////////////////////////////////////////////////
//ID File Flash
////////////////////////////////////////////////////////////////////////////////
#define flash_file_ID_FLASH_DISK  (0x73AB0000)
#define flash_file_ID_FNP         (0x00010000)
#define flash_file_ID_GFX         (0x00020000)
#define flash_file_ID_TXT         (0x00030000)
#define flash_file_ID_SCRIPT      (0x000F0000)

#define sc_str_END                (0)
#define sc_str_ID                 (1)
#define sc_str_CMDRES             (2)
#define sc_str_CMDWIN             (3)
#define sc_str_CMDSTR             (4)
#define sc_str_FNTMD              (5)
#define sc_str_ENTER              (13)
*/

////////////////////////////////////////////////////////////////////////////////
//SELECT Config
////////////////////////////////////////////////////////////////////////////////
#define BQ24090_port        GPIOC

#define BQISET1_wp_pin      0
#define BQISET1_wp_bit      dH_BIT(BQISET1_wp_pin)
#define BQISET1(_val_)      BQ24090_port->BSRR = dH_PORT_BSSR(BQISET1_wp_pin,_val_)
#define BQISET1_ON()        BQISET1(1)
#define BQISET1_OFF()       BQISET1(0)

#define BQISET2_wp_pin      1
#define BQISET2_wp_bit      dH_BIT(BQISET2_wp_pin)
#define BQISET2(_val_)      BQ24090_port->BSRR = dH_PORT_BSSR(BQISET2_wp_pin,_val_)
#define BQISET2_ON()        BQISET2(1)
#define BQISET2_OFF()       BQISET2(0)

#define BQPWRGOOD_pin       2
#define BQPWRGOOD_bit       dH_BIT(BQPWRGOOD_pin)
#define BQPWRGOOD()         (BQ24090_port->IDR & BQPWRGOOD_bit)
#define isBQPWRGOOD()       (BQPWRGOOD()==0)


//////

#define BTHC_PWR_port       GPIOA
#define BTHC_PWR_wp_pin     1
#define BTHC_PWR_wp_bit     dH_BIT(BTHC_PWR_wp_pin)
#define BTHC_PWR(_val_)     BTHC_PWR_port->BSRR = dH_PORT_BSSR(BTHC_PWR_wp_pin,_val_)
#define BTHC_PWR_ON()       BTHC_PWR(1)
#define BTHC_PWR_OFF()      BTHC_PWR(0)
#define BT_Power(_val)      BTHC_PWR(_val)

#define BTHC_RES_port       GPIOA
#define BTHC_RES_wp_pin     7
#define BTHC_RES_wp_bit     dH_BIT(BTHC_RES_wp_pin)
#define BTHC_RES(_val_)     BTHC_RES_port->BSRR = dH_PORT_BSSR(BTHC_RES_wp_pin,_val_)
#define BTHC_RES_ON()       BTHC_RES(0)
#define BTHC_RES_OFF()      BTHC_RES(1)
#define BT_RES(_val)        BTHC_RES(_val)

#define BTHC_KE1_port       GPIOC
#define BTHC_KE1_wp_pin     4
#define BTHC_KE1_wp_bit     dH_BIT(BTHC_KE1_wp_pin)
#define BTHC_KE1(_val_)     BTHC_KE1_port->BSRR = dH_PORT_BSSR(BTHC_KE1_wp_pin,_val_)
#define BTHC_KE1_ON()       BTHC_KE1(1)
#define BTHC_KE1_OFF()      BTHC_KE1(0)

#define BTHC_KE2_port       GPIOC
#define BTHC_KE2_wp_pin     5
#define BTHC_KE2_wp_bit     dH_BIT(BTHC_KE2_wp_pin)
#define BTHC_KE2(_val_)     BTHC_KE2_port->BSRR = dH_PORT_BSSR(BTHC_KE2_wp_pin,_val_)
#define BTHC_KE2_ON()       BTHC_KE2(1)
#define BTHC_KE2_OFF()      BTHC_KE2(0)


#define BT_AT(_val)         BTHC_KE1(_val)


#define EN_SI_port          GPIOB
#define EN_SI_wp_pin        8
#define EN_SI_wp_bit        dH_BIT(EN_SI_wp_pin)
#define EN_SI(_val_)        EN_SI_port->BSRR = dH_PORT_BSSR(EN_SI_wp_pin,_val_)
#define EN_SI_ON()          EN_SI(1)
#define EN_SI_OFF()         EN_SI(0)



#define SI_C2C_port         GPIOB
#define SI_C2C_wp_pin       5
#define SI_C2C_wp_bit       dH_BIT(SI_C2C_wp_pin)
#define SI_C2C(_val_)       SI_C2C_port->BSRR = dH_PORT_BSSR(SI_C2C_wp_pin,_val_)
#define SI_C2C_ON()         SI_C2C(1)
#define SI_C2C_OFF()        SI_C2C(0)

#define SI_C2D_port         GPIOB
#define SI_C2D_wp_pin       4
#define SI_C2D_wp_bit       dH_BIT(SI_C2D_wp_pin)
#define SI_C2D(_val_)       SI_C2D_port->BSRR = dH_PORT_BSSR(SI_C2D_wp_pin,_val_)
#define SI_C2D_ON()         SI_C2D(1)
#define SI_C2D_OFF()        SI_C2D(0)

/*
#define SDDETECT_port       GPIOA
#define SDDETECT_pin        1
#define SDDETECT_bit        dH_BIT(SDDETECT_pin)
#define SDDETECT()          (SDDETECT_port->IDR & SDDETECT_bit)
#define isSDDETECT()        (SDDETECT==0)
*/

//RMODEE
//RMODEV
//LMODEE
//LMODEV
//LUPDOE
//LUPDOV

/*
#define U1_SEL_port         GPIOA
#define U1_SEL_wp_pin       1
#define U1_SEL_wp_bit       dH_BIT(U1_SEL_wp_pin)
#define U1_SEL(_val_)       U1_SEL_port->BSRR = dH_PORT_BSSR(U1_SEL_wp_pin,_val_)
#define U1_SEL_ESP()        U1_SEL(0)
#define U1_SEL_USB()        U1_SEL(1)

#define U2_SEL_port         GPIOE
#define U2_SEL_wp_pin       2
#define U2_SEL_wp_bit       dH_BIT(U2_SEL_wp_pin)
#define U2_SEL(_val_)       U2_SEL_port->BSRR = dH_PORT_BSSR(U2_SEL_wp_pin,_val_)
#define U2_SEL_BTM()        U2_SEL(0)
#define U2_SEL_COI()        U2_SEL(1)

#define S3_SEL_port         GPIOB
#define S3_SEL_wp_pin       6
#define S3_SEL_wp_bit       dH_BIT(S3_SEL_wp_pin)
#define S3_SEL(_val_)       S3_SEL_port->BSRR = dH_PORT_BSSR(S3_SEL_wp_pin,_val_)
#define S3_SEL_STE()        S3_SEL(0)
#define S3_SEL_FLA()        S3_SEL(1)

#define S2_SEL_port         GPIOC
#define S2_SEL_wp_pin       5
#define S2_SEL_wp_bit       dH_BIT(S2_SEL_wp_pin)
#define S2_SEL(_val_)       S2_SEL_port->BSRR = dH_PORT_BSSR(S2_SEL_wp_pin,_val_)
#define S2_SEL_ESP()        S2_SEL(0)
#define S2_SEL_BTM()        S2_SEL(1)

#define STECS_port          GPIOC
#define STECS_wp_pin        6
#define STECS_wp_bit        dH_BIT(STECS_wp_pin)
#define STECS(_val_)        STECS_port->BSRR = dH_PORT_BSSR(STECS_wp_pin,_val_)
#define STECS_SHIFT()       STECS(0)
#define STECS_LOAD()        STECS(1)

#define PLLNSS_port         GPIOA
#define PLLNSS_wp_pin       8
#define PLLNSS_wp_bit       dH_BIT(PLLNSS_wp_pin)
#define PLLNSS(_val_)       PLLNSS_port->BSRR = dH_PORT_BSSR(PLLNSS_wp_pin,_val_)
#define PLLNSS_ON()         PLLNSS(0)
#define PLLNSS_OFF()        PLLNSS(1)

#define LEDPWM_port         GPIOB
#define LEDPWM_wp_pin       1
#define LEDPWM_wp_bit       dH_BIT(LEDPWM_wp_pin)
#define LEDPWM(_val_)       LEDPWM_port->BSRR = dH_PORT_BSSR(LEDPWM_wp_pin,_val_)
#define LEDPWM_ON()         LEDPWM(1)
#define LEDPWM_OFF()        LEDPWM(0)
*/
////////////////////////////////////////////////////////////////////////////////
//ADC Config
////////////////////////////////////////////////////////////////////////////////
/*
#define ADC_port            GPIOC

#define ADCBAT_wp_pin       0
#define ADCBAT_wp_bit       dH_BIT(ADCBAT_wp_pin)
#define ADCINX_wp_pin       1
#define ADCINX_wp_bit       dH_BIT(ADCINX_wp_pin)
#define ADCINY_wp_pin       2
#define ADCINY_wp_bit       dH_BIT(ADCINY_wp_pin)
#define ADCV5E_wp_pin       3
#define ADCV5E_wp_bit       dH_BIT(ADCV5E_wp_pin)

extern u16 Read_ADC_GroupBIT(u32 sel);
#define Read_ADC_BAT()    Read_ADC_GroupBIT(ADCBAT_wp_bit)
#define Read_ADC_INY()    Read_ADC_GroupBIT(ADCINX_wp_bit)      //X AND Y SWITCHED WHY ???
#define Read_ADC_INX()    Read_ADC_GroupBIT(ADCINY_wp_bit)      //X AND Y SWITCHED WHY ???
#define Read_ADC_V5E()    Read_ADC_GroupBIT(ADCV5E_wp_bit)
*/

////////////////////////////////////////////////////////////////////////////////
//SD Config
////////////////////////////////////////////////////////////////////////////////
//#define SD_SPI_NSS(_val_)      GPIOA->BSRR = dH_PORT_BSSR(4,_val_)


#define SD_SPI_port         GPIOB
#define SD_SPI_wp_pin       12
#define SD_SPI_wp_bit       dH_BIT(SD_SPI_wp_pin)
#define SD_SPINSS(_val_)    SD_SPI_port->BSRR = dH_PORT_BSSR(SD_SPI_wp_pin,_val_)
#define SD_SPI_ON()         SD_SPINSS(1)
#define SD_SPI_OFF()        SD_SPINSS(0)
#define SD_SPI_NSS(_val_)   SD_SPINSS(_val_)


//#define SD_POWER(_val_)     GPIOC->BSRR = dH_PORT_BSSR(4,_val_)
#define SD_POWER_port       GPIOB
#define SD_POWER_wp_pin     3
#define SD_POWER_wp_bit     dH_BIT(SD_POWER_wp_pin)
#define SD_POWER(_val_)     SD_POWER_port->BSRR = dH_PORT_BSSR(SD_POWER_wp_pin,_val_)
#define SD_POWER_ON()       SD_POWER(1)
#define SD_POWER_OFF()      SD_POWER(0)

extern void SD_InitGPIO(void);
extern void SD_PowerOFF(void);
extern void SD_PowerON(void);


//////////////////////////////////////////////////////////////////////////////////////
// BUZZER
//////////////////////////////////////////////////////////////////////////////////////

#define Timer1PWM_Cycles        ((u32)8)

#define BeepFreq(_freq)         PWM_Timer1CFG(_freq, Timer1PWM_Cycles)
#define BeepVol(_vol)           PWM_T1C2(_vol) //TIM1->CCR2 = _vol


#define BeepPlaySound_INQ()     bpl_InitNum(2)
#define BeepPlaySound_NAME()    bpl_InitNum(3)

extern void PWM_T1C2(u16 val);
extern u32 PWM_Timer1CFG(u32 freq, u32 PWMCycles);

//////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////
// DAC Config
//////////////////////////////////////////////////////////////////////////////////////

#define DAC1_POS()      DMA_GetCurrDataCounter(DMA2_Channel3)
#define DAC2_POS()      DMA_GetCurrDataCounter(DMA2_Channel4)

extern void Start_DAC(void);
extern void Stop_DAC(void);
extern void Setup_DAC(u32 TimerFreq, u16 *dacBuf1, u16 *dacBuf2, u16 dacBufSize);


extern void Init(void);

extern void SPI0_SendWait(void);
extern void SPI0_ReceiveWait(void);
extern void SPI0_Send(u16 b);
extern u16 SPI0_Receive(void);
extern u8 SPI0_IsBusy(void);
extern void SPI0_WaitBusy(void);
extern u8 SPI0_WriteReadByte(u8 b);

extern void SPI0_Init(void);
extern void SPI0_ReadBlock(u8 *buf, u32 size);
extern void SPI0_WriteBlock(u8 *buf, u32 size);

extern void SPI2_SendWait(void);
extern void SPI2_ReceiveWait(void);
extern void SPI2_Send(u16 b);
extern u16 SPI2_Receive(void);
extern u8 SPI2_IsBusy(void);
extern void SPI2_WaitBusy(void);
extern u8 SPI2_WriteReadByte(u8 b);
extern u8 SPI2_WriteReadByte_mc_CRC(u8 b);
extern u8 SPI2_WriteByte(u16 b);

extern void SPI2_Init(void);
extern void SPI2_ReadBlock(u8 *buf, u32 size);
extern void SPI2_WriteBlock(u8 *buf, u32 size);


extern void SPI3_SendWait(void);
extern void SPI3_ReceiveWait(void);
extern void SPI3_Send(u16 b);
extern u16 SPI3_Receive(void);
extern u8 SPI3_IsBusy(void);
extern void SPI3_WaitBusy(void);
extern u8 SPI3_WriteReadByte(u8 b);

extern void SPI3_Init(void);
extern void SPI3_ReadBlock(u8 *buf, u32 size);
extern void SPI3_WriteBlock(u8 *buf, u32 size);
extern void SPI3_WriteReadBlock(u8 *bufo, u8 *bufi, u32 size);

extern u8 CRC_mc_8BIT(u8 crc, u8 b);
extern u8 CRC_mc_8BIT_block(u8 crc, u8 *buf, u32 size);
extern vu8 SPI_CRC8;
extern u8 SPI_WriteReadByte(u8 b);
extern u8 SPI_WriteReadByte_mc_CRC(u8 b);
extern u8 SPI_WriteByte(u16 b);

extern void PWM_T1C1_PER(u8 val);
extern void PWM_T1C1_BYTE(u8 val);
extern void PWM_T1C4_PER(u8 val);
extern void PWM_T1C4_BYTE(u8 val);

#define Lcd_LedLightByte(_val)      PWM_T1C1_BYTE(_val)
#define Lcd_LedLightPercent(_val)   PWM_T1C1_PER(_val)
#define Led_LedLightByte(_val)      PWM_T1C4_BYTE(_val)
#define Led_LedLightPercent(_val)   PWM_T1C4_PER(_val)

#endif
