
//////////////////////////////////////////////////////////////////////////////////////
// 
// Low level for STM32F100
// 
// By Rob F. / Entire Group
// 
//////////////////////////////////////////////////////////////////////////////////////

#include "SysType.h"
#include "hardware.h"

extern void stm32_Init(void);
extern unsigned int stm32_TimerGetReload (char tnum);
//extern unsigned int stm32_GetPCLK1 (void);
//extern unsigned int stm32_GetPCLK2 (void);




RCC_ClocksTypeDef MPU_ClocksStatus;



void SPI0_SendWait(void)
{
    while (!(SPI1->SR & SPI_I2S_FLAG_TXE));
}

void SPI0_ReceiveWait(void)
{
		while( !(SPI1->SR & SPI_I2S_FLAG_RXNE));
}

void SPI0_Send(u16 b)
{
    SPI0_SendWait();
    SPI_I2S_SendData(SPI1, b);
}

u16 SPI0_Receive(void)
{
		SPI0_ReceiveWait();
		return SPI_I2S_ReceiveData(SPI1);
}
//while( SPI1->SR & SPI_I2S_FLAG_BSY ); // wait until SPI is not busy anymore
u8 SPI0_IsBusy(void)
{
		return SPI1->SR & SPI_I2S_FLAG_BSY;
}

void SPI0_WaitBusy(void)
{
		while (SPI0_IsBusy());
}

u8 SPI0_WriteReadByte(u8 b)
{
  SPI0_Send(b);
  return SPI0_Receive();
}

void SPI0_GPIO_OFF(void)
{
  
  GPIO_InitTypeDef GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA |
                         RCC_APB2Periph_GPIOB, ENABLE);
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
      // CONFIG FOR PB3=CLK PB4=MISO, PB5=MOSI, PA15=NSS + REMAP SPI
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;     //CLK, MISO, MOSI
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;//PP;
      GPIO_Init(GPIOB, &GPIO_InitStructure);

      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;     //SOFT NSS + HOLD
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;//PP;
      GPIO_Init(GPIOA, &GPIO_InitStructure);
  
      GPIO_ResetBits(GPIOB, GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5);
      GPIO_ResetBits(GPIOA, GPIO_Pin_15);
  
}

void SPI0_GPIO_ON_A(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA |
                         RCC_APB2Periph_GPIOB, ENABLE);
  
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
      // CONFIG FOR PA5=CLK PA6=MISO, PA7=MOSI, PA4=NSS
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;     //CLK
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
      GPIO_Init(GPIOA, &GPIO_InitStructure);
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;     //MISO
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
      GPIO_Init(GPIOA, &GPIO_InitStructure);
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;     //MOSI
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
      GPIO_Init(GPIOA, &GPIO_InitStructure);
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;     //SOFT NSS + HOLD
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
      GPIO_Init(GPIOA, &GPIO_InitStructure);
  
      GPIOA->BSRR = dH_PORT_BSSR(5, 1);
}

void SPI0_GPIO_ON_B(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA |
                         RCC_APB2Periph_GPIOB, ENABLE);
  
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
      // CONFIG FOR PB3=CLK PB4=MISO, PB5=MOSI, PA15=NSS + REMAP SPI
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;     //CLK
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
      GPIO_Init(GPIOB, &GPIO_InitStructure);
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;     //MISO
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
      GPIO_Init(GPIOB, &GPIO_InitStructure);
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;     //MOSI
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
      GPIO_Init(GPIOB, &GPIO_InitStructure);
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;     //SOFT NSS + HOLD
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
      GPIO_Init(GPIOA, &GPIO_InitStructure);
  
      GPIOB->BSRR = dH_PORT_BSSR(3, 0);
}

u8 SPI0_AB_SEL=0;

void SPI0_GPIO_ON(u8 rema)
{
  if (rema==0)
  {
      dH_PORT_CFG_MD(GPIOB->CRL, 3, 3 | (0<<2));    //PB3 = IN + PULLING
      SPI1->CR1 |=  SPI_CPOL_High;     //CPOL = 1
      AFIO->MAPR = (AFIO->MAPR & (~GPIO_Remap_SPI1)) | 0x07000000;
      dH_PORT_CFG_MD(GPIOA->CRL, 5, 3 | (2<<2));    //PA5 = OUTAF + PUSH PULL

  } else {
      dH_PORT_CFG_MD(GPIOA->CRL, 5, 3 | (0<<2));    //PA5 = IN + PULLING
      SPI1->CR1 &= ~SPI_CPOL_High;     //CPOL = 0
      AFIO->MAPR |=  GPIO_Remap_SPI1 | 0x07000000;
      dH_PORT_CFG_MD(GPIOB->CRL, 3, 3 | (2<<2));    //PB3 = OUTAF + PUSH PULL
  }
  
}


void SPI0_Init(void)
{
//  GPIO_InitTypeDef GPIO_InitStructure;
  SPI_InitTypeDef   SPI_InitStructure;

  
  
  // Enable peripheral clocks --------------------------------------------------
  // GPIOA, GPIOB and SPI1 clock enable
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA |
                         RCC_APB2Periph_GPIOB |
                         RCC_APB2Periph_SPI1, ENABLE);
      //GPIO_PinRemapConfig(GPIO_Remap_SPI1, ENABLE);

/*
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
      // CONFIG FOR PB3=CLK PB4=MISO, PB5=MOSI, PA15=NSS + REMAP SPI
      GPIO_PinRemapConfig(GPIO_Remap_SPI1, ENABLE);
//      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
//      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
//      GPIO_Init(GPIOB, &GPIO_InitStructure);
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;     //CLK
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;//PP;
      GPIO_Init(GPIOB, &GPIO_InitStructure);
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;     //MISO
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
      GPIO_Init(GPIOB, &GPIO_InitStructure);
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;     //MOSI
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;//PP;
      GPIO_Init(GPIOB, &GPIO_InitStructure);

      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;     //SOFT NSS + HOLD
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;//PP;
      GPIO_Init(GPIOA, &GPIO_InitStructure);
*/

//  SPI0_GPIO_ON();

  // SPI1 Config -------------------------------------------------------------
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex; //SPI_Direction_1Line_Tx; //SPI_Direction_2Lines_FullDuplex;
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
/*
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;//SPI_CPOL_High;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
  //SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;//  2Edge;
  SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
  {
    const u32 presc[]={SPI_BaudRatePrescaler_8,SPI_BaudRatePrescaler_2,SPI_BaudRatePrescaler_4,SPI_BaudRatePrescaler_8,SPI_BaudRatePrescaler_16,
                       SPI_BaudRatePrescaler_32,SPI_BaudRatePrescaler_64,SPI_BaudRatePrescaler_128,SPI_BaudRatePrescaler_256};
    SPI_InitStructure.SPI_BaudRatePrescaler=presc[spd%9];
  }
  
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
*/
  SPI_InitStructure.SPI_DataSize = SPI0_CFG_DSIZE;
  SPI_InitStructure.SPI_CPOL = SPI0_CFG_CPOL;
  SPI_InitStructure.SPI_CPHA = SPI0_CFG_CPHA;
  SPI_InitStructure.SPI_NSS = SPI0_CFG_NSS;
  SPI_InitStructure.SPI_BaudRatePrescaler=SPI0_CFG_BAUD;
  SPI_InitStructure.SPI_FirstBit = SPI0_CFG_FIRSTBIT;


  SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_Init(SPI1, &SPI_InitStructure);
  
  // Enable SPI1
  SPI_Cmd(SPI1, ENABLE);

}



vu8 SPI0_tmpx[1]={0xFF};
void SPI0_DMA_StartWaitEnd(void)
{
  SPI1->CR2 |= (SPI_I2S_DMAReq_Rx | SPI_I2S_DMAReq_Tx);     // Enable the SPI Rx/Tx DMA request
  DMA1_Channel2->CCR |= 0x00000001;                         // Enable the DMA SPI RX Stream 
  DMA1_Channel3->CCR |= 0x00000001;                         // Enable the DMA SPI TX Stream 
  // Waiting the end of Data transfer //Check SPI TX/RX Flag Finish Transfer
  while ((DMA1->ISR & (DMA1_FLAG_TC3 | DMA1_FLAG_TC2))!=(DMA1_FLAG_TC3 | DMA1_FLAG_TC2));
  DMA1->IFCR = DMA1_FLAG_TC3 | DMA1_FLAG_TC2;               //Clear SPI TX/RX Flag
  DMA1_Channel3->CCR &=~0x00000001;                         // Disable the DMA SPI TX Stream 
  DMA1_Channel2->CCR &=~0x00000001;                         // Disable the DMA SPI RX Stream 
  SPI1->CR2 &=~(SPI_I2S_DMAReq_Rx | SPI_I2S_DMAReq_Tx);     // Disable the SPI Rx/Tx DMA request
}

void SPI0_ReadBlock(u8 *buf, u32 size)
{
  if (size==0) return;
  if (DMA1_Channel3->CPAR==0)
  {
    while (size) { *buf = SPI0_WriteReadByte(SPI0_tmpx[0]); buf++; size--; }
    return;
  }
  //TX
  DMA1_Channel3->CNDTR = size;
  DMA1_Channel3->CMAR  = (u32)(SPI0_tmpx);
  DMA1_Channel3->CCR   = SPI_DMA_CCR(DMA_MemoryInc_Disable | DMA_DIR_PeripheralDST);
  //RX
  DMA1_Channel2->CNDTR = size;
  DMA1_Channel2->CMAR  = (u32)(buf);
  DMA1_Channel2->CCR   = SPI_DMA_CCR(DMA_MemoryInc_Enable | DMA_DIR_PeripheralSRC);
  //Transfer DMA Data
  SPI0_DMA_StartWaitEnd();
}

void SPI0_WriteBlock(u8 *buf, u32 size)
{    
  if (size==0) return;
  if (DMA1_Channel3->CPAR==0)
  {
    while (size) { SPI0_WriteReadByte(*buf); buf++; size--; }
    return;
  }
  //TX
  DMA1_Channel3->CNDTR = size;
  DMA1_Channel3->CMAR  = (u32)(buf);
  DMA1_Channel3->CCR   = SPI_DMA_CCR(DMA_MemoryInc_Enable | DMA_DIR_PeripheralDST);
  //RX
  DMA1_Channel2->CNDTR = size;
  DMA1_Channel2->CMAR  = (u32)(SPI0_tmpx);
  DMA1_Channel2->CCR   = SPI_DMA_CCR(DMA_MemoryInc_Disable | DMA_DIR_PeripheralSRC);
  //Transfer DMA Data
  SPI0_DMA_StartWaitEnd();
}

void SPI0_DMA_Init(void)
{
      RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
      DMA1_Channel3->CPAR  = (u32)(&(SPI1->DR));
      DMA1_Channel2->CPAR  = (u32)(&(SPI1->DR));
}

/////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////



void SPI2_SendWait(void)
{
    while (!(SPI2->SR & SPI_I2S_FLAG_TXE));
}

void SPI2_ReceiveWait(void)
{
		while( !(SPI2->SR & SPI_I2S_FLAG_RXNE));
}

void SPI2_Send(u16 b)
{
    SPI2_SendWait();
    SPI_I2S_SendData(SPI2, b);
}

u16 SPI2_Receive(void)
{
		SPI2_ReceiveWait();
		return SPI_I2S_ReceiveData(SPI2);
}
//while( SPI2->SR & SPI_I2S_FLAG_BSY ); // wait until SPI is not busy anymore
u8 SPI2_IsBusy(void)
{
		return SPI2->SR & SPI_I2S_FLAG_BSY;
}

void SPI2_WaitBusy(void)
{
		while (SPI2_IsBusy());
}

u8 SPI2_WriteReadByte(u8 b)
{
  SPI2_Send(b);
  return SPI2_Receive();
}

u8 SPI2_WriteReadByte_mc_CRC(u8 b)
{
  SPI2_Send(b);
  SPI_CRC8=CRC_mc_8BIT(SPI_CRC8, b);
  return SPI2_Receive();
}
u8 SPI2_WriteByte(u16 b)
{
    u8 i=b>>8;
    u8 c=b;
    if (i==0) i++;
    while (i--) c=SPI2_WriteReadByte(b);
    return c;
}

void SPI2_GPIO_ON(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOB, ENABLE);
  
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
      // CONFIG FOR PB13=CLK PB14=MISO, PB15=MOSI, PB12=NSS
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;    //CLK
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
      GPIO_Init(GPIOB, &GPIO_InitStructure);
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;    //MISO
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
      GPIO_Init(GPIOB, &GPIO_InitStructure);
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;    //MOSI
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
      GPIO_Init(GPIOB, &GPIO_InitStructure);
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;    //SOFT NSS
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
      GPIO_Init(GPIOB, &GPIO_InitStructure);
  
      GPIOB->BSRR = dH_PORT_BSSR(12, 1);
}




void SPI2_Init(void)
{
//  GPIO_InitTypeDef GPIO_InitStructure;
  SPI_InitTypeDef   SPI_InitStructure;

  
  
  // Enable peripheral clocks --------------------------------------------------
  // GPIOA, GPIOB and SPI1 clock enable
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);
      //GPIO_PinRemapConfig(GPIO_Remap_SPI1, ENABLE);


//  SPI0_GPIO_ON();

  // SPI1 Config -------------------------------------------------------------
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex; //SPI_Direction_1Line_Tx; //SPI_Direction_2Lines_FullDuplex;
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
  SPI_InitStructure.SPI_DataSize = SPI2_CFG_DSIZE;
  SPI_InitStructure.SPI_CPOL = SPI2_CFG_CPOL;
  SPI_InitStructure.SPI_CPHA = SPI2_CFG_CPHA;
  SPI_InitStructure.SPI_NSS = SPI2_CFG_NSS;
  SPI_InitStructure.SPI_BaudRatePrescaler=SPI2_CFG_BAUD;
  SPI_InitStructure.SPI_FirstBit = SPI2_CFG_FIRSTBIT;

  SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_Init(SPI2, &SPI_InitStructure);
  
  // Enable SPI2
  SPI_Cmd(SPI2, ENABLE);
}



vu8 SPI2_tmpx[1]={0xFF};
void SPI2_DMA_StartWaitEnd(void)
{
  SPI2->CR2 |= (SPI_I2S_DMAReq_Rx | SPI_I2S_DMAReq_Tx);     // Enable the SPI Rx/Tx DMA request
  DMA1_Channel4->CCR |= 0x00000001;                         // Enable the DMA SPI RX Stream 
  DMA1_Channel5->CCR |= 0x00000001;                         // Enable the DMA SPI TX Stream 
  // Waiting the end of Data transfer //Check SPI TX/RX Flag Finish Transfer
  while ((DMA1->ISR & (DMA1_FLAG_TC5 | DMA1_FLAG_TC4))!=(DMA1_FLAG_TC5 | DMA1_FLAG_TC4));
  DMA1->IFCR = DMA1_FLAG_TC5 | DMA1_FLAG_TC4;               //Clear SPI TX/RX Flag
  DMA1_Channel5->CCR &=~0x00000001;                         // Disable the DMA SPI TX Stream 
  DMA1_Channel4->CCR &=~0x00000001;                         // Disable the DMA SPI RX Stream 
  SPI2->CR2 &=~(SPI_I2S_DMAReq_Rx | SPI_I2S_DMAReq_Tx);     // Disable the SPI Rx/Tx DMA request
}

void SPI2_ReadBlock(u8 *buf, u32 size)
{
  if (size==0) return;
  if (DMA1_Channel5->CPAR==0)
  {
    while (size) { *buf = SPI2_WriteReadByte(SPI2_tmpx[0]); buf++; size--; }
    return;
  }
  //TX
  DMA1_Channel5->CNDTR = size;
  DMA1_Channel5->CMAR  = (u32)(SPI2_tmpx);
  DMA1_Channel5->CCR   = SPI_DMA_CCR(DMA_MemoryInc_Disable | DMA_DIR_PeripheralDST);
  //RX
  DMA1_Channel4->CNDTR = size;
  DMA1_Channel4->CMAR  = (u32)(buf);
  DMA1_Channel4->CCR   = SPI_DMA_CCR(DMA_MemoryInc_Enable | DMA_DIR_PeripheralSRC);
  //Transfer DMA Data
  SPI2_DMA_StartWaitEnd();
}

void SPI2_WriteBlock(u8 *buf, u32 size)
{    
  if (size==0) return;
  if (DMA1_Channel5->CPAR==0)
  {
    while (size) { SPI2_WriteReadByte(*buf); buf++; size--; }
    return;
  }
  //TX
  DMA1_Channel5->CNDTR = size;
  DMA1_Channel5->CMAR  = (u32)(buf);
  DMA1_Channel5->CCR   = SPI_DMA_CCR(DMA_MemoryInc_Enable | DMA_DIR_PeripheralDST);
  //RX
  DMA1_Channel4->CNDTR = size;
  DMA1_Channel4->CMAR  = (u32)(SPI2_tmpx);
  DMA1_Channel4->CCR   = SPI_DMA_CCR(DMA_MemoryInc_Disable | DMA_DIR_PeripheralSRC);
  //Transfer DMA Data
  SPI2_DMA_StartWaitEnd();
}

void SPI2_DMA_Init(void)
{
      RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
      DMA1_Channel5->CPAR  = (u32)(&(SPI2->DR));
      DMA1_Channel4->CPAR  = (u32)(&(SPI2->DR));
}





/////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////



void SPI3_SendWait(void)
{
    while (!(SPI3->SR & SPI_I2S_FLAG_TXE));
}

void SPI3_ReceiveWait(void)
{
		while( !(SPI3->SR & SPI_I2S_FLAG_RXNE));
}

void SPI3_Send(u16 b)
{
    SPI3_SendWait();
    SPI_I2S_SendData(SPI3, b);
}

u16 SPI3_Receive(void)
{
		SPI3_ReceiveWait();
		return SPI_I2S_ReceiveData(SPI3);
}
//while( SPI3->SR & SPI_I2S_FLAG_BSY ); // wait until SPI is not busy anymore
u8 SPI3_IsBusy(void)
{
		return SPI3->SR & SPI_I2S_FLAG_BSY;
}

void SPI3_WaitBusy(void)
{
		while (SPI3_IsBusy());
}

u8 SPI3_WriteReadByte(u8 b)
{
  SPI3_Send(b);
  return SPI3_Receive();
}


void SPI3_GPIO_ON(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC, ENABLE);
  
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
      // CONFIG FOR PB3=CLK PB4=MISO, PB5=MOSI, PB12=NSS
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;    //CLK
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
      GPIO_Init(GPIOB, &GPIO_InitStructure);
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;    //MISO
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
      GPIO_Init(GPIOB, &GPIO_InitStructure);
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;    //MOSI
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
      GPIO_Init(GPIOB, &GPIO_InitStructure);
      
      GPIO_InitStructure.GPIO_Pin = SPI3_NSSAwp_bit;    //SOFT NSSA
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
      GPIO_Init(SPI3_NSSAport, &GPIO_InitStructure);
      SPI3_NSSA(1);
  
      GPIO_InitStructure.GPIO_Pin = SPI3_NSSBwp_bit;    //SOFT NSSB
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
      GPIO_Init(SPI3_NSSBport, &GPIO_InitStructure);
      SPI3_NSSB(1);
}




void SPI3_Init(void)
{
//  GPIO_InitTypeDef GPIO_InitStructure;
  SPI_InitTypeDef   SPI_InitStructure;

  
  
  // Enable peripheral clocks --------------------------------------------------
  // GPIOA, GPIOB and SPI1 clock enable
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3, ENABLE);
      //GPIO_PinRemapConfig(GPIO_Remap_SPI1, ENABLE);


//  SPI0_GPIO_ON();

  // SPI1 Config -------------------------------------------------------------
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex; //SPI_Direction_1Line_Tx; //SPI_Direction_2Lines_FullDuplex;
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
  SPI_InitStructure.SPI_DataSize = SPI3_CFG_DSIZE;
  SPI_InitStructure.SPI_CPOL = SPI3_CFG_CPOL;
  SPI_InitStructure.SPI_CPHA = SPI3_CFG_CPHA;
  SPI_InitStructure.SPI_NSS = SPI3_CFG_NSS;
  SPI_InitStructure.SPI_BaudRatePrescaler=SPI3_CFG_BAUD;
  SPI_InitStructure.SPI_FirstBit = SPI3_CFG_FIRSTBIT;

  SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_Init(SPI3, &SPI_InitStructure);
  
  // Enable SPI2
  SPI_Cmd(SPI3, ENABLE);
}


vu8 SPI3_tmpx[1]={0xFF};
void SPI3_DMA_StartWaitEnd(void)
{
/*
  //const u32 dmaflag = SPI3_DMA_FLAG();//(DMA2_FLAG_TC2 | DMA2_FLAG_TC1) & 0x0FFFFFFF;
  SPI3->CR2 |= (SPI_I2S_DMAReq_Rx | SPI_I2S_DMAReq_Tx);     // Enable the SPI Rx/Tx DMA request
  DMA2_Channel1->CCR |= 0x00000001;                         // Enable the DMA SPI RX Stream 
  DMA2_Channel2->CCR |= 0x00000001;                         // Enable the DMA SPI TX Stream 
  // Waiting the end of Data transfer //Check SPI TX/RX Flag Finish Transfer
  while ((DMA2->ISR & SPI3_DMA_FLAG())!=SPI3_DMA_FLAG());
  DMA2->IFCR = SPI3_DMA_FLAG();//DMA2_FLAG_TC2 | DMA2_FLAG_TC1;               //Clear SPI TX/RX Flag
  DMA2_Channel1->CCR &=~0x00000001;                         // Disable the DMA SPI TX Stream 
  DMA2_Channel2->CCR &=~0x00000001;                         // Disable the DMA SPI RX Stream 
  SPI3->CR2 &=~(SPI_I2S_DMAReq_Rx | SPI_I2S_DMAReq_Tx);     // Disable the SPI Rx/Tx DMA request
*/
      SPI3_DMA_Start();
      while (SPI3_DMA_IsBusy());
      SPI3_DMA_End();
}

void SPI3_ReadBlock(u8 *buf, u32 size)
{
  if (size==0) return;
  if (SPI3_DMA_IsDisable())
  {
    while (size) { *buf = SPI3_WriteReadByte(SPI3_tmpx[0]); buf++; size--; }
    return;
  }
  SPI3_DMA_SetUp(SPI3_tmpx, buf, size, 0,1);
  //Transfer DMA Data
  SPI3_DMA_StartWaitEnd();
}

void SPI3_WriteBlock(u8 *buf, u32 size)
{    
  if (size==0) return;
  if (SPI3_DMA_IsDisable())
  {
    while (size) { SPI3_WriteReadByte(*buf); buf++; size--; }
    return;
  }
  SPI3_DMA_SetUp(buf, SPI3_tmpx, size, 1,0);
  //Transfer DMA Data
  SPI3_DMA_StartWaitEnd();
}

void SPI3_WriteReadBlock(u8 *bufo, u8 *bufi, u32 size)
{    
  if (size==0) return;
  if (SPI3_DMA_IsDisable())
  {
    while (size) { *bufi = SPI3_WriteReadByte(*bufo); bufo++; bufi++; size--; }
    return;
  }
  SPI3_DMA_SetUp(bufo, bufi, size, 1,1);
  //Transfer DMA Data
  SPI3_DMA_StartWaitEnd();
}

void SPI3_DMA_Init(void)
{
      RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA2, ENABLE);
      DMA2_Channel2->CPAR  = (u32)(&(SPI3->DR));
      DMA2_Channel1->CPAR  = (u32)(&(SPI3->DR));
}




/////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////

/*

void PWRPROG_VCC_OFF(void)
{
    PWRPROG_SET_IN();
    POWER_PROG_EN_OFF();
}
void PWRPROG_VCC_LOW(void)
{
    POWER_PROG_EN_OFF();
    PWRPROG_SET_OUT();
    PWRPROG(1);
}
void PWRPROG_VCC_HIGH(void)
{
    PWRPROG_SET_IN();
    POWER_PROG_EN_ON();
}

*/
/*
void Setup_ADC(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
  
    ADC_InitTypeDef ADC_InitStructure;
  
    RCC_ADCCLKConfig(RCC_PCLK2_Div6);
  
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
    ADC_DeInit(ADC1);
  
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
//    ADC_InitStructure.ADC_ScanConvMode = ENABLE;
//    ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
    ADC_InitStructure.ADC_ScanConvMode = DISABLE; //�� ���� ����� ��� �����������
    ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;//����� ��� ��� ����� ����  
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfChannel = 4;
    ADC_Init(ADC1, &ADC_InitStructure);
  
            // Enable ADC1
            ADC_Cmd(ADC1, ENABLE);
              
            //����������
            // Enable ADC1 reset calibration register
            ADC_ResetCalibration(ADC1);
            // Check the end of ADC1 reset calibration register
            while (ADC_GetResetCalibrationStatus(ADC1));

            // Start ADC1 calibration
            ADC_StartCalibration(ADC1);
            // Check the end of ADC1 calibration
            while (ADC_GetCalibrationStatus(ADC1));
//GPIO Init            

    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IPD;
    GPIO_InitStructure.GPIO_Pin   = ADCBAT_wp_bit | ADCV5E_wp_bit;
    GPIO_Init(ADC_port, &GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IPD;
    GPIO_InitStructure.GPIO_Pin   = ADCINX_wp_bit | ADCINY_wp_bit;
    GPIO_Init(ADC_port, &GPIO_InitStructure);

  
}

u16 Read_ADC_GroupBIT(u32 sel)
{
  u8 channel=0;
  switch (sel)
  {
    case ADCBAT_wp_bit: channel=10; break;
    case ADCINX_wp_bit: channel=11; break;
    case ADCINY_wp_bit: channel=12; break;
    case ADCV5E_wp_bit: channel=13; break;
  }
  ADC_RegularChannelConfig(ADC1, channel, 1, ADC_SampleTime_1Cycles5);
  // Start the conversion
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);
  // Wait until conversion completion
  while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);
  // Get the conversion value
  return ADC_GetConversionValue(ADC1);
}



u16 Read_ADC1(u8 channel)
{
  ADC_RegularChannelConfig(ADC1, channel, 1, ADC_SampleTime_41Cycles5*0 + ADC_SampleTime_1Cycles5);
  // Start the conversion
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);
  // Wait until conversion completion
  while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);
  // Get the conversion value
  return ADC_GetConversionValue(ADC1);
}

u32 TERMO_VCC_MEASURE(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
//    PWRPROG_VCC_OFF();
//    PUP_EN_OFF();
    
    
  
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AIN;;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    return Read_ADC1(9);
  
  
}
*/
u8 CRC_mc_8BIT(u8 crc, u8 b)
{
    u8 j;
    for (j = 0; j < 8; j++)
    {
      crc <<= 1;
      crc ^= ((((b << j) ^ crc) & 0x80) ? 0x9 : 0);
    }
    return crc;
}

vu8 SPI_CRC8;

u8 CRC_mc_8BIT_block(u8 crc, u8 *buf, u32 size)
{
  while(size)
  {
    crc=CRC_mc_8BIT(crc, *buf++);
    size--;
  }
  return crc;
}


u8 SPI_WriteReadByte(u8 b)
{
  SPI0_Send(b);
  return SPI0_Receive();
}

u8 SPI_WriteReadByte_mc_CRC(u8 b)
{
  SPI0_Send(b);
  SPI_CRC8=CRC_mc_8BIT(SPI_CRC8, b);
  return SPI0_Receive();
}

u8 SPI_WriteByte(u16 b)
{
    u8 i=b>>8;
    u8 c=b;
    if (i==0) i++;
    while (i--) c=SPI_WriteReadByte(b);
    return c;
}


/*
void LCD_Init(void)
{
      GPIO_InitTypeDef GPIO_InitStructure;
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  
      GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
      GPIO_InitStructure.GPIO_Pin = LCD_A0_bit | LCD_RES_bit;
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;//PP;
      GPIO_Init(LCD_port, &GPIO_InitStructure);

      GPIO_SetBits(LCD_port, LCD_A0_bit | LCD_RES_bit);
}
*/
/*
void FLASH_Init(void)
{
      GPIO_InitTypeDef GPIO_InitStructure;
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  
      GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
      GPIO_InitStructure.GPIO_Pin = FLASH_wp_bit;
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;//PP;
      GPIO_Init(FLASH_port, &GPIO_InitStructure);

      GPIO_SetBits(FLASH_port, FLASH_wp_bit);
}
*/
void PWM_T1C1(u16 val)
{
    TIM1->CCR1 = val;
}

void PWM_T1C1_PER(u8 val)
{
    PWM_T1C1( (TIM1->ARR*val)/100 );
}

void PWM_T1C1_BYTE(u8 val)
{
    PWM_T1C1( (TIM1->ARR*val)/255 );
}

void PWM_T1C4(u16 val)
{
    TIM1->CCR4 = val;
}

void PWM_T1C4_PER(u8 val)
{
    PWM_T1C4( (TIM1->ARR*val)/100 );
}

void PWM_T1C4_BYTE(u8 val)
{
    PWM_T1C4( (TIM1->ARR*val)/255 );
}





void PWM_T1C2(u16 val)
{
    TIM3->CCR3 = val;
}


u32 PWM_Timer1CALC(u32 freq, u32 PWMCycles)
{
      u32 presc = MPU_ClocksStatus.SYSCLK_Frequency / PWMCycles / freq;
      u32 clkdiv=1;
      if ((presc / clkdiv)>65535) clkdiv<<=1;
      if ((presc / clkdiv)>65535) clkdiv<<=1;
      presc = presc / clkdiv;
      return (presc & 0xFFFF) | ((clkdiv>>1)<<16);
}



u32 PWM_Timer1CFG(u32 freq, u32 PWMCycles)
{
      u32 d = PWM_Timer1CALC(freq, PWMCycles);
      u16 presc = d;
      u16 clkdiv = (d >> 8) & 0x0300;
  
      TIM3->PSC = presc;
      u16 w = TIM3->CR1 & (~0x0300);
      TIM3->CR1 = w | clkdiv;
      
  
      return presc;
}


u32 PWM_Timer1CFG_HARD(u32 freq, u32 PWMCycles)
{
      TIM_TimeBaseInitTypeDef TIBAST;
      u32 d = PWM_Timer1CALC(freq, PWMCycles);
      u16 presc = d;
      u16 clkdiv = (d >> 8) & 0x0300;
  
  // Time base configuration
  TIBAST.TIM_Period = PWMCycles-1;//255;                           //ARR
  TIBAST.TIM_Prescaler = presc;
  TIBAST.TIM_ClockDivision = clkdiv;
  TIBAST.TIM_CounterMode = TIM_CounterMode_Up;
  TIBAST.TIM_RepetitionCounter = 0;
  TIM_TimeBaseInit(TIM3, &TIBAST);
      return presc;
}




void PWM_Timer1_Config(u32 TimerMcs, u32 PWMCycles)
{
  //u32 perdiv=32;
  //u32 presc = ((TimerMcs*256) / (256000000 / (MPU_ClocksStatus.SYSCLK_Frequency/perdiv)));
  GPIO_InitTypeDef GPIO_InitStructure;
  TIM_OCInitTypeDef  TIM_OCInitStructure;
//  TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;

//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
  
  PWM_Timer1CFG_HARD(1000000/TimerMcs, PWMCycles);
  
  
  // Time base configuration
//  TIM_TimeBaseStructure.TIM_Period = perdiv-1;//255;                           //ARR
//  TIM_TimeBaseStructure.TIM_Prescaler = presc;    
//  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
//  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
//  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
//  TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure); 
 
//  TIM_OCStructInit(&TIM_OCInitStructure);
  TIM_OCInitStructure.TIM_OCMode=TIM_OCMode_PWM1;
  TIM_OCInitStructure.TIM_OutputState=TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_OutputNState=TIM_OutputNState_Enable;    
  TIM_OCInitStructure.TIM_Pulse=0;                                   //CCR1
  TIM_OCInitStructure.TIM_OCPolarity=TIM_OCPolarity_High;            //Negative = Low
  TIM_OCInitStructure.TIM_OCNPolarity=TIM_OCNPolarity_Low;
  TIM_OCInitStructure.TIM_OCIdleState=TIM_OCIdleState_Reset;
  TIM_OCInitStructure.TIM_OCNIdleState=TIM_OCNIdleState_Reset;
  TIM_OC3Init(TIM3, &TIM_OCInitStructure);
  TIM_CtrlPWMOutputs(TIM3, ENABLE);

//  TIM_OCStructInit(&TIM_OCInitStructure);
//  TIM_OCInitStructure.TIM_OCMode=TIM_OCMode_PWM1;
//  TIM_OCInitStructure.TIM_OutputState=TIM_OutputState_Enable;
//  TIM_OCInitStructure.TIM_OutputNState=TIM_OutputNState_Disable;    
//  TIM_OCInitStructure.TIM_Pulse=128;                                   //CCR1
//  TIM_OCInitStructure.TIM_OCPolarity=TIM_OCPolarity_High;            //Negative = Low
//  TIM_OCInitStructure.TIM_OCNPolarity=TIM_OCNPolarity_High;
//  TIM_OCInitStructure.TIM_OCIdleState=TIM_OCIdleState_Reset;
//  TIM_OCInitStructure.TIM_OCNIdleState=TIM_OCNIdleState_Reset;
//  TIM_OC2Init(TIM3, &TIM_OCInitStructure);

  TIM_Cmd(TIM3, ENABLE);
  
      
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
      
      //GPIO_PinRemapConfig(GPIO_PartialRemap_TIM1 , ENABLE);

      //PA8 = PWM OUT
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
      GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
      GPIO_Init(GPIOB, &GPIO_InitStructure);
  
 }

 
 
 
 
 
 
 
 
 
 
 
 
 
 
////////////////////////////////////////////////////////////////////////////////////////////////////////// 
////////////////////////////////////////////////////////////////////////////////////////////////////////// 
////////////////////////////////////////////////////////////////////////////////////////////////////////// 
////////////////////////////////////////////////////////////////////////////////////////////////////////// 
 
void PWM_T3C4(u16 val)
{
    TIM3->CCR4 = val;
}
void PWM_T3C4_BYTE(u8 val)
{
    PWM_T3C4( (TIM3->ARR*val)/255 );
}

void PWM_T8C3(u16 val)
{
    TIM8->CCR3 = val;
}
void PWM_T8C3_BYTE(u8 val)
{
    PWM_T8C3( (TIM8->ARR*val)/255 );
}

 
//void PWM_Timer3_Config(u32 TimerMcs)
void PWM_Timer_Config(u8 TIMNum, u8 CHNNum, u32 TimerMcs)
  
{
  u32 presc = ((TimerMcs*256) / (256000000 / (MPU_ClocksStatus.SYSCLK_Frequency/256)));
//  GPIO_InitTypeDef GPIO_InitStructure;
  TIM_OCInitTypeDef  TIM_OCInitStructure;
  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
  TIM_TypeDef* TIMx;
  void(*TIM_OCxInit)(TIM_TypeDef*, TIM_OCInitTypeDef*);
  switch (TIMNum)
  { default:
    case 1: RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE); TIMx = TIM1; break;
    case 2: RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE); TIMx = TIM2; break;
    case 3: RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE); TIMx = TIM3; break;
    case 4: RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE); TIMx = TIM4; break;
    case 5: RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE); TIMx = TIM5; break;
    case 6: RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE); TIMx = TIM6; break;
    case 7: RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE); TIMx = TIM7; break;
    case 8: RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8, ENABLE); TIMx = TIM8; break;
  }
  switch (CHNNum)
  { default:
    case 1: TIM_OCxInit=TIM_OC1Init; break;
    case 2: TIM_OCxInit=TIM_OC2Init; break;
    case 3: TIM_OCxInit=TIM_OC3Init; break;
    case 4: TIM_OCxInit=TIM_OC4Init; break;
  }
  
  
  // Time base configuration
  TIM_TimeBaseStructure.TIM_Period = 255;                           //ARR
  TIM_TimeBaseStructure.TIM_Prescaler = presc;
  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
  TIM_TimeBaseInit(TIMx, &TIM_TimeBaseStructure); 
 
//  TIM_OCStructInit(&TIM_OCInitStructure);
  TIM_OCInitStructure.TIM_OCMode=TIM_OCMode_PWM1;
  TIM_OCInitStructure.TIM_OutputState=TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_OutputNState=TIM_OutputNState_Disable;    
  TIM_OCInitStructure.TIM_Pulse=0;                                   //CCR1
  TIM_OCInitStructure.TIM_OCPolarity=TIM_OCPolarity_High;            //Negative = Low
  TIM_OCInitStructure.TIM_OCNPolarity=TIM_OCNPolarity_High;
  TIM_OCInitStructure.TIM_OCIdleState=TIM_OCIdleState_Reset;
  TIM_OCInitStructure.TIM_OCNIdleState=TIM_OCNIdleState_Reset;
  TIM_OCxInit(TIMx, &TIM_OCInitStructure);
  TIM_CtrlPWMOutputs(TIMx, ENABLE);

//  TIM_OCStructInit(&TIM_OCInitStructure);
//  TIM_OCInitStructure.TIM_OCMode=TIM_OCMode_PWM1;
//  TIM_OCInitStructure.TIM_OutputState=TIM_OutputState_Enable;
//  TIM_OCInitStructure.TIM_OutputNState=TIM_OutputNState_Disable;    
//  TIM_OCInitStructure.TIM_Pulse=128;                                   //CCR1
//  TIM_OCInitStructure.TIM_OCPolarity=TIM_OCPolarity_High;            //Negative = Low
//  TIM_OCInitStructure.TIM_OCNPolarity=TIM_OCNPolarity_High;
//  TIM_OCInitStructure.TIM_OCIdleState=TIM_OCIdleState_Reset;
//  TIM_OCInitStructure.TIM_OCNIdleState=TIM_OCNIdleState_Reset;
//  TIM_OC4Init(TIM1, &TIM_OCInitStructure);

  TIM_Cmd(TIMx, ENABLE);
/*
      //PA8 = PWM OUT
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
      GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_11;
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
      GPIO_Init(GPIOA, &GPIO_InitStructure);
*/

//    PWM_T3C4_BYTE(128);


    
 }
 
 
 
 
 
 
 
 
/*
void Led_Init(void)
{
  
//#define LEDA_port         GPIOC
//#define LEDA_R_pin        14
//#define LEDA_R_bit        dH_BIT(LEDA_R_pin)
//#define LEDA_G_pin        13
//#define LEDA_G_bit        dH_BIT(LEDA_G_pin)
//#define LEDAR(_val_)      LEDA_port->BSRR = dH_PORT_BSSR(LEDA_R_pin,(_val_))
//#define LEDAG(_val_)      LEDA_port->BSRR = dH_PORT_BSSR(LEDA_G_pin,(_val_))
  
      GPIO_InitTypeDef GPIO_InitStructure;
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA |
                             RCC_APB2Periph_GPIOB |
                             RCC_APB2Periph_GPIOC, ENABLE);
  
      GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;//PP;

      GPIO_InitStructure.GPIO_Pin = LEDA_R_bit | LEDA_G_bit;
      GPIO_Init(LEDA_port, &GPIO_InitStructure);
      GPIO_SetBits(LEDA_port, LEDA_R_bit | LEDA_G_bit);
  
      GPIO_InitStructure.GPIO_Pin = LEDB_R_bit | LEDB_G_bit;
      GPIO_Init(LEDB_port, &GPIO_InitStructure);
      GPIO_SetBits(LEDB_port, LEDB_R_bit | LEDB_G_bit);
  
      GPIO_InitStructure.GPIO_Pin = LEDC_R_bit | LEDC_G_bit;
      GPIO_Init(LEDC_port, &GPIO_InitStructure);
      GPIO_SetBits(LEDC_port, LEDC_R_bit | LEDC_G_bit);
  
  
}
*/

void Key_Init(void)
{
      GPIO_InitTypeDef GPIO_InitStructure;
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

      GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
      GPIO_InitStructure.GPIO_Pin = KEY_0_bit;
      GPIO_Init(KEY_port, &GPIO_InitStructure);
  
}



//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////

/*
void SDIO_IRQHandler(void)
{
  // Process All SDIO Interrupt Sources
  SD_ProcessIRQSrc();
  //SDIO_WriteData
}

*/
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
void SelectInitGPIO(void)
{
  
  GPIO_InitTypeDef GPIO_InitStructure;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOE, ENABLE);
  
  GPIO_InitStructure.GPIO_Pin = BQISET1_wp_bit | BQISET2_wp_bit;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(BQ24090_port, &GPIO_InitStructure);
  
  GPIO_InitStructure.GPIO_Pin = BQPWRGOOD_bit;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(BQ24090_port, &GPIO_InitStructure);


  GPIO_InitStructure.GPIO_Pin = BTHC_PWR_wp_bit;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(BTHC_PWR_port, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin = BTHC_RES_wp_bit;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(BTHC_RES_port, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin = BTHC_KE1_wp_bit;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(BTHC_KE1_port, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin = BTHC_KE2_wp_bit;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(BTHC_KE2_port, &GPIO_InitStructure);

  BTHC_RES(0);
  BTHC_KE1(0);
  BTHC_KE2(0);
  
  BTHC_PWR(0);
  BTHC_RES(1);
  BTHC_KE1(1);
  BTHC_KE2(1);
  
  
  GPIO_InitStructure.GPIO_Pin = EN_SI_wp_bit;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(EN_SI_port, &GPIO_InitStructure);
  EN_SI(0);
  
  GPIO_InitStructure.GPIO_Pin = SI_C2C_wp_bit;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(SI_C2C_port, &GPIO_InitStructure);
  SI_C2C(0);
  
  GPIO_InitStructure.GPIO_Pin = SI_C2D_wp_bit;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
  GPIO_Init(SI_C2D_port, &GPIO_InitStructure);
  SI_C2D(0);
  
/*
  GPIO_InitStructure.GPIO_Pin = SDDETECT_bit;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(SDDETECT_port, &GPIO_InitStructure);
*/

/*  
 //SELEC USART1 TO ESP/USB
  GPIO_InitStructure.GPIO_Pin = U1_SEL_wp_bit;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(U1_SEL_port, &GPIO_InitStructure);
  
  U1_SEL_USB();

 //SELEC USART2 TO BLUETOOTH/COIMPLANT
  GPIO_InitStructure.GPIO_Pin = U2_SEL_wp_bit;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(U2_SEL_port, &GPIO_InitStructure);

  U2_SEL_BTM();
  
 //SELEC SPI3 TO STE(ExtendedGPIO)/FLASH(M25)
  GPIO_InitStructure.GPIO_Pin = S3_SEL_wp_bit;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(S3_SEL_port, &GPIO_InitStructure);
  
  S3_SEL_STE();

 //SELEC SPI2 TO ESP/USB
  GPIO_InitStructure.GPIO_Pin = S2_SEL_wp_bit;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(S2_SEL_port, &GPIO_InitStructure);
  
  S2_SEL_BTM();

 //STE Extended Port Shift Register
  GPIO_InitStructure.GPIO_Pin = STECS_wp_bit;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(STECS_port, &GPIO_InitStructure);
  
  STECS_SHIFT();
  
 //STE Extended Port Shift Register
  GPIO_InitStructure.GPIO_Pin = PLLNSS_wp_bit;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(PLLNSS_port, &GPIO_InitStructure);
  
  PLLNSS_OFF();

 //LED PWM CONFIG
  GPIO_InitStructure.GPIO_Pin = LEDPWM_wp_bit;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(LEDPWM_port, &GPIO_InitStructure);

  GPIO_PinRemapConfig(GPIO_Remap_SPI1, ENABLE);

  LEDPWM_ON();

 //test modem config
 //test modem config
 //test modem config
 //test modem config
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  GPIO_SetBits(GPIOB, GPIO_Pin_10);
 
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
*/
  
}

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
void FSMC_Init(void)
{
  
    GPIO_InitTypeDef GPIO_InitStructure;
    FSMC_NANDInitTypeDef FSMC_NANDInitStructure;
    FSMC_NAND_PCCARDTimingInitTypeDef p;
//    FSMC_NORSRAMTimingInitTypeDef pp;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOE, ENABLE);

    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  
    //!< SRAM Data lines configuration
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_14 | GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOD, &GPIO_InitStructure);
  
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOE, &GPIO_InitStructure);

    //!< SRAM Address lines configuration
    //A16 - pin 11
    //A17 - pin 12
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11 | GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOD, &GPIO_InitStructure);
    
    //!< NOE and NWE configuration
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOD, &GPIO_InitStructure);
    
    //!< NE1 configuration CS chip select
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOD, &GPIO_InitStructure);
    
    //!< NWAIT NAND pin configuration
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOD, &GPIO_InitStructure);
    
    //!< CLOCK OUTPUT pin configuration
    //GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
    //GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    //GPIO_Init(GPIOD, &GPIO_InitStructure);
    
//-- FSMC Configuration ------------------------------------------------------

RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, ENABLE);//�������� ��������.

//-- FSMC Configuration ------------------------------------------------------
/*
p.FSMC_SetupTime = 0x1;
p.FSMC_WaitSetupTime = 0x1;
p.FSMC_HoldSetupTime = 0x2;
p.FSMC_HiZSetupTime = 0x2;
*/
/*
// Max Speed Maybe not stable
p.FSMC_SetupTime = 0x0;
p.FSMC_WaitSetupTime = 0x1;
p.FSMC_HoldSetupTime = 0x1;
p.FSMC_HiZSetupTime = 0x0;
*/
p.FSMC_SetupTime = 0x1;
p.FSMC_WaitSetupTime = 0x1;
p.FSMC_HoldSetupTime = 0x1;
p.FSMC_HiZSetupTime = 0x0;





FSMC_NANDInitStructure.FSMC_Bank = FSMC_Bank2_NAND;
FSMC_NANDInitStructure.FSMC_Waitfeature = FSMC_Waitfeature_Enable;
FSMC_NANDInitStructure.FSMC_MemoryDataWidth = FSMC_MemoryDataWidth_8b;
FSMC_NANDInitStructure.FSMC_ECC = FSMC_ECC_Disable;
FSMC_NANDInitStructure.FSMC_ECCPageSize = FSMC_ECCPageSize_256Bytes;
FSMC_NANDInitStructure.FSMC_TCLRSetupTime = 0x00;
FSMC_NANDInitStructure.FSMC_TARSetupTime = 0x00;
FSMC_NANDInitStructure.FSMC_CommonSpaceTimingStruct = &p;
FSMC_NANDInitStructure.FSMC_AttributeSpaceTimingStruct = &p;

FSMC_NANDInitStructure.FSMC_AddressLowMapping = FSMC_AddressLowMapping_Direct;

FSMC_NANDInit(&FSMC_NANDInitStructure);




//RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOE | RCC_APB2Periph_AFIO, ENABLE);
//RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, ENABLE);

//!< FSMC NAND Bank Cmd Test 
FSMC_NANDCmd(FSMC_Bank2_NAND, ENABLE);

FSMC_NANDECCCmd(FSMC_Bank2_NAND,ENABLE);

}
/*
const u16 table_dac1_12bit[] =
{ 3000,1000,
  2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,
  2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,
  2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,
  2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048
};

const u16 table_dac2_12bit[] =
{ 4000,1000,
  2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,
  2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,
  2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,
  2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048
};
*/
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////

void Start_DAC(void)
{
    TIM_Cmd(TIM6, ENABLE);
    TIM_Cmd(TIM7, ENABLE);
}

void Stop_DAC(void)
{
    TIM_Cmd(TIM6, DISABLE);
    TIM_Cmd(TIM7, DISABLE);
}


void Setup_DAC(u32 TimerFreq, u16 *dacBuf1, u16 *dacBuf2, u16 dacBufSize)
{
  
  //u32 presc = ((TimerNs*256) / (256000000000 / (MPU_ClocksStatus.SYSCLK_Frequency/256)));
//  u32 presc = ((TimerNs) / (256000000000 / MPU_ClocksStatus.SYSCLK_Frequency));
//  u32 presc = ((1000000000/TimerFreq) / (256000000000 / MPU_ClocksStatus.SYSCLK_Frequency));
//  u32 presc = ((1000000000/TimerFreq) / (256000000000 / MPU_ClocksStatus.SYSCLK_Frequency));
//  u32 peri = 2;
//  u32 presc = MPU_ClocksStatus.SYSCLK_Frequency / (TimerFreq * peri);
  u32 presc = 0;
  u32 peri;
  while (1)
  {
    peri= MPU_ClocksStatus.SYSCLK_Frequency / (presc+1) /  (TimerFreq );
    if ((peri & 0xFFFF0000)==0) break;
    presc++;
  }
//  u32 presc =  (MPU_ClocksStatus.SYSCLK_Frequency * TimerNs) / (256000);
//  GPIO_InitTypeDef GPIO_InitStructure;
//  TIM_OCInitTypeDef  TIM_OCInitStructure;
//  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
//  TIM_TypeDef* TIMx;
  
  
  // Time base configuration
//  TIM_TimeBaseStructure.TIM_Period = 255;                           //ARR
//  TIM_TimeBaseStructure.TIM_Prescaler = presc;
//  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
//  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
//  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
   
 ///////////////////////
  
	DAC_InitTypeDef DAC_InitStructure;
	DMA_InitTypeDef DMA_InitStructure;
  TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
  GPIO_InitTypeDef GPIO_InitStructure;

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA2, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6 | RCC_APB1Periph_TIM7, ENABLE);
  
    //DAC PIN PA4/PA5 - FOR SOUND GEMERATOR
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  Stop_DAC();

	// ������������� ������ 7 � 6
	TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseStructure.TIM_Period = peri;//0x300; 
	TIM_TimeBaseStructure.TIM_Prescaler = presc;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM7, &TIM_TimeBaseStructure);
	//TIM_TimeBaseStructure.TIM_Period = 8;//0x300;
	TIM_TimeBaseInit(TIM6, &TIM_TimeBaseStructure);

	TIM_SelectOutputTrigger(TIM6, TIM_TRGOSource_Update);
	TIM_SelectOutputTrigger(TIM7, TIM_TRGOSource_Update);


	// ������������� DMA1 ����� 3
	DMA_DeInit(DMA2_Channel3);
	DMA_InitStructure.DMA_PeripheralBaseAddr = (u32)&DAC->DHR12R1;
	DMA_InitStructure.DMA_MemoryBaseAddr = (u32)(dacBuf1);//(u32)&table_dac1_12bit;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
	DMA_InitStructure.DMA_BufferSize = dacBufSize;//sizeof(table_dac1_12bit)>>1;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA2_Channel3, &DMA_InitStructure);

	DMA_Cmd(DMA2_Channel3, ENABLE);

	// ������������� ���1 ����� 4
	DMA_DeInit(DMA2_Channel4);
	DMA_InitStructure.DMA_PeripheralBaseAddr = (u32)&DAC->DHR12R2;
	DMA_InitStructure.DMA_MemoryBaseAddr = (u32)(dacBuf2);//(u32)&table_dac2_12bit;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
	DMA_InitStructure.DMA_BufferSize = dacBufSize;//sizeof(table_dac2_12bit)>>1;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA2_Channel4, &DMA_InitStructure);

	DMA_Cmd(DMA2_Channel4, ENABLE);


  // ������������� ���
	DAC_InitStructure.DAC_LFSRUnmask_TriangleAmplitude = 0;
	DAC_InitStructure.DAC_Trigger = DAC_Trigger_T7_TRGO;
	DAC_InitStructure.DAC_WaveGeneration = DAC_WaveGeneration_None;
	DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Disable;
	DAC_Init(DAC_Channel_1, &DAC_InitStructure);
	DAC_InitStructure.DAC_Trigger = DAC_Trigger_T6_TRGO;
	DAC_Init(DAC_Channel_2, &DAC_InitStructure);

	DAC_Cmd(DAC_Channel_1, ENABLE);
	DAC_Cmd(DAC_Channel_2, ENABLE);


	DAC_DMACmd(DAC_Channel_1, ENABLE);
	DAC_DMACmd(DAC_Channel_2, ENABLE);

	// ��������� ������ ������� 7
//	TIM_Cmd(TIM6, ENABLE);
//	TIM_Cmd(TIM7, ENABLE);

  
  
}


//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
void TestGPIO(void)
{
//  GPIO_InitTypeDef GPIO_InitStructure;
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    //TEST PIN PA4/PA5 - FOR SOUND GEMERATOR
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
//  GPIO_Init(GPIOA, &GPIO_InitStructure);
//  BEEP_L(1);
//  BEEP_R(1);
  
  //TEST PIN PC6
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
//  GPIO_Init(GPIOC, &GPIO_InitStructure);

    //TEST PIN PB6
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
//  GPIO_Init(GPIOB, &GPIO_InitStructure);

    //TEST PIN PB3
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
//  GPIO_Init(GPIOB, &GPIO_InitStructure);
  

}



void SystemInit(void)
{
        stm32_Init();
        //PWR_PVDCmd(DISABLE);
}


void MCO_Config(void) 
{ 
    GPIO_InitTypeDef is; 
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE); 
        
    is.GPIO_Pin = GPIO_Pin_8; 
    is.GPIO_Speed = GPIO_Speed_50MHz; 
    is.GPIO_Mode = GPIO_Mode_AF_PP; 
    GPIO_Init(GPIOA,&is); 
    
//    RCC_MCOConfig(RCC_MCO_PLLCLK_Div2);
    RCC_MCOConfig(RCC_MCO_SYSCLK); 
    return; 
}


void Init(void)
{


        RCC_GetClocksFreq(&MPU_ClocksStatus);
//        PCLK1=RCC_ClocksStatus.PCLK1_Frequency;// stm32_GetPCLK1();
//        PCLK2=RCC_ClocksStatus.PCLK2_Frequency;// stm32_GetPCLK2();
        PCLK1_NOP=MPU_ClocksStatus.PCLK1_Frequency/1000000;
        TIMER0_PER=stm32_TimerGetReload(0);
        TIMER1_PER=stm32_TimerGetReload(1);
        TIMER2_PER=stm32_TimerGetReload(2);
        TIMER3_PER=stm32_TimerGetReload(3);
        TIMER4_PER=stm32_TimerGetReload(4);  

        TestGPIO();
        SelectInitGPIO();
  

//        SPI0_Init();
//        SPI0_DMA_Init();
//        SPI0_GPIO_ON_A();

//        SPI2_Init();
//        SPI2_DMA_Init();
//        SPI2_GPIO_ON();

//        SPI3_Init();
//        SPI3_DMA_Init();
//        SPI3_GPIO_ON();

//        PWM_Timer_Config(3,4, 500);
//        PWM_T3C4_BYTE(200);
        //PWM_Timer_Config(8,3, 500);
        //PWM_T8C3_BYTE(150);
        
        PWM_Timer1_Config(1000000/1600 ,8);
        PWM_T1C2(1);
        PWM_T1C2(10);
        PWM_T1C2(0);

        PWM_Timer1_Config(1000000/3200 ,8);
        PWM_T1C2(1);
        PWM_T1C2(10);
        PWM_T1C2(0);

//        LCD_Init();
//        FLASH_Init();
        
//        Led_Init();

        Key_Init();
  
//          Setup_ADC();
//          Setup_ADC(1000000000/44100);//Setup_DAC(1000000/44100);
          //Setup_DAC(sbFREQ, , , sbBufSize); 
          //Setup_DAC( 44100, (u16 *)&table_dac1_12bit, (u16 *)&table_dac2_12bit, sizeof(table_dac2_12bit)>>1);
        
        //USART1_Init();
        //FSMC_Init();
//        MCO_Config();
//        USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);    //ENABLE UART RS
  
}





//


