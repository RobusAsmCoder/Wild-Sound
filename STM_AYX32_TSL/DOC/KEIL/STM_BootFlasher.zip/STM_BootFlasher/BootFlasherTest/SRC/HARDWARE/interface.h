//////////////////////////////////////////////////////////////////////////////////////
// By Rob F. / Entire Group
//////////////////////////////////////////////////////////////////////////////////////

#ifndef __INTERFACE_H
#define __INTERFACE_H

#include "SysType.h"
#include "rb_fifo.h"


#define interface_USART_MacroFunctionConfig(_name)      \
extern Trb_fifo uart_##_name##_fifo_in;                 \
extern Trb_fifo uart_##_name##_fifo_out;                \
extern u16 Read_##_name##_Byte(void);                   \
extern void Send_##_name##_Byte(u8 c);                  \
extern void Send_##_name##_String(char *s);             \
extern void Send_##_name##_HEX(u32 da, u8 Dig);         \
extern void Send_##_name##_DEC(u32 da);                 \
extern void Uart_##_name##_Init(u32 baud, u8 parstop);  \

interface_USART_MacroFunctionConfig(RS);
interface_USART_MacroFunctionConfig(BT);
interface_USART_MacroFunctionConfig(SL);

extern void Uart_CFG(USART_InitTypeDef *USART_InitStructure, u32 baud, u8 parstop);


extern void InterfaceInit(void);

#endif
