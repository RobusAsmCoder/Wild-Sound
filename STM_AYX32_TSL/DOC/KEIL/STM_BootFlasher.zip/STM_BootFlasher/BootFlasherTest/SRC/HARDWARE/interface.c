//////////////////////////////////////////////////////////////////////////////////////
// 
// Middle level interface for STM32F100
// 
// By Rob F. / Entire Group
// 
//////////////////////////////////////////////////////////////////////////////////////
#include "SysType.h"
#include "hardware.h"
#include "interface.h"
//#include "core_cm3.h"
#include "cortex_rb_sys.h"
#include "rb_fifo.h"
#include "rb_util.h"





///////////////////////////
// UARTS Allocation
///////////////////////////
vu8 Mode_RS_CFG = 0;      //0=RS 1=CFG
///////////////////////////
// USART RS
///////////////////////////

#define interface_USART_MacroFunctionGenerator(_name,_usart,_insize,_ousize)\
rb_fifo_alloc(uart_##_name##_fifo_in,   128);                               \
rb_fifo_alloc(uart_##_name##_fifo_out,  128);                               \
void _usart##_IRQHandler(void) __irq                                        \
{                                                                           \
  if(USART_GetITStatus(_usart, USART_IT_RXNE) != RESET)                     \
  {                                                                         \
    rb_fifo_wr( &uart_##_name##_fifo_in, USART_ReceiveData(_usart) );       \
  }                                                                         \
  if(USART_GetITStatus(_usart, USART_IT_TXE) != RESET)                      \
  {                                                                         \
    if ( rb_fifo_size(&uart_##_name##_fifo_out) )                           \
    {                                                                       \
      USART_SendData(_usart, rb_fifo_rd(&uart_##_name##_fifo_out));         \
    } else {                                                                \
      USART_ITConfig(_usart, USART_IT_TXE, DISABLE);                        \
    }                                                                       \
  }                                                                         \
}                                                                           \
u16 Read_##_name##_Byte(void)                                               \
{                                                                           \
    if ( rb_fifo_size(&uart_##_name##_fifo_in) )                            \
    {                                                                       \
      return rb_fifo_rd(&uart_##_name##_fifo_in);                           \
    }                                                                       \
    return 0xFFFF;                                                          \
}                                                                           \
void Send_##_name##_Byte(u8 c)                                              \
{                                                                           \
      while ( rb_fifo_free(&uart_##_name##_fifo_out)==0 );                  \
      NVIC_DisableIRQ(_usart##_IRQChannel);                                 \
      rb_fifo_wr(&uart_##_name##_fifo_out, c);                              \
      USART_ITConfig(_usart, USART_IT_TXE, ENABLE);                         \
      NVIC_EnableIRQ(_usart##_IRQChannel);                                  \
}                                                                           \
void Send_##_name##_String(char *s)                                         \
{                                                                           \
        while (*s) Send_##_name##_Byte(*s++);                               \
}                                                                           \
void Send_##_name##_HEX(u32 da, u8 Dig)                                     \
{                                                                           \
    rb_IntToProc(da, rb_istr_mode_HEX | Dig, &Send_##_name##_Byte);         \
}                                                                           \
void Send_##_name##_DEC(u32 da)                                             \
{                                                                           \
    rb_IntToProc(da, rb_istr_mode_DEC, &Send_##_name##_Byte);               \
}                                                                           \
void Uart_##_name##_Init(u32 baud, u8 parstop)                              \
{                                                                           \
   NVIC_InitTypeDef NVIC_InitStructure;                                     \
   USART_InitTypeDef USART_InitStructure;                                   \
      _usart##_GPIO();                                                      \
      USART_Cmd(_usart, DISABLE);                                           \
      rb_fifo_flush(&uart_##_name##_fifo_in, rb_fifo_size(&uart_##_name##_fifo_in));      \
      Uart_CFG(&USART_InitStructure, baud, parstop);                        \
      USART_Init(_usart, &USART_InitStructure);                             \
      NVIC_InitStructure.NVIC_IRQChannel = _usart##_IRQChannel;             \
      NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;             \
      NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;                    \
      NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;                       \
      NVIC_Init(&NVIC_InitStructure);                                       \
      USART_ITConfig(_usart, USART_IT_RXNE, ENABLE);                        \
      USART_Cmd(_usart, ENABLE);                                            \
}                                                                           \







// par = 0 - None
//     = 1 - Odd
//     = 2 - Even
//stop = 0 - 0.5
//     = 1 - 1
//     = 2 - 2
//     = 3 - 1.5
void Uart_CFG(USART_InitTypeDef *USART_InitStructure, u32 baud, u8 parstop)
{
      u16 stop = parstop & 0x0F;
      u16 par  = parstop >> 4;
      u16 wlen = USART_WordLength_8b;
  
      switch (par)
      {
        case 1: par=USART_Parity_Odd;  wlen = USART_WordLength_9b; break;
        case 2: par=USART_Parity_Even; wlen = USART_WordLength_9b; break;
        default:par=USART_Parity_No;                               break;
      }
      switch (stop)
      {
        case 0: stop=USART_StopBits_0_5;  break;
        case 2: stop=USART_StopBits_2;    break;
        case 3: stop=USART_StopBits_1_5;  break;
        default:stop=USART_StopBits_1;    break;
      }
  
      USART_InitStructure->USART_BaudRate = baud;
      USART_InitStructure->USART_WordLength = wlen;//USART_WordLength_8b;
      USART_InitStructure->USART_StopBits = stop;//Uart_Get_Stop(parstop & 0x0F);//USART_StopBits_1;
      USART_InitStructure->USART_Parity = par;//Uart_Get_Parity(parstop >> 4);//USART_Parity_No;
      USART_InitStructure->USART_HardwareFlowControl = USART_HardwareFlowControl_None;
      USART_InitStructure->USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
}

/*
void USART1_Init(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;
// �������� ������������ ����� � � USART1
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_USART1, ENABLE);
// TxD (PA9) push-pull With Alternate
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
//����������� UART
  USART1->BRR=0x09C4; //BaudRate 9600
  USART1->CR1 |= USART_CR1_UE; //��������� ������ USART1
//  USART1->CR1 |= USART_CR1_TE; //�������� ����������
//����� ��������� ������ ����������� ���������
  NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQChannel;     //  1_IRQn; //�����
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;   //���������
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;          //��������� ���������
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;             //�������� �����
  NVIC_Init(&NVIC_InitStructure);                             //��������������
  USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);    //ENABLE UART RS
}

void USART2_Init(void)
{
}
void USART3_Init(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;
// Port B and USART3
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
// TxD (PB10) push-pull
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
// RxD (PB11) push-pull
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
//Config UART
  USART3->BRR=0x09C4; //BaudRate 9600
  USART3->CR1 |= USART_CR1_UE; //��������� ������ USART1
//  USART1->CR1 |= USART_CR1_TE; //�������� ����������
//����� ��������� ������ ����������� ���������
  NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQChannel;//  1_IRQn; //�����
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0; //���������
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;//��������� ���������
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; //�������� �����
  NVIC_Init(&NVIC_InitStructure); //��������������
  USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);    //ENABLE UART RS
}
*/

/*
void Uart_RS_Init(u32 baud, u8 parstop)
{
   USART_InitTypeDef USART_InitStructure;
      USART1_Init();
      rb_fifo_flush(&uart_RS_fifo_in, rb_fifo_size(&uart_RS_fifo_in));
      USART_Cmd(USART1, DISABLE);
      Uart_CFG(&USART_InitStructure, baud, parstop);
      USART_Init(USART1, &USART_InitStructure);
      USART_Cmd(USART1, ENABLE);
}


void Uart_BT_Init(u32 baud, u8 parstop)
{
   USART_InitTypeDef USART_InitStructure;
      //USART2_Init();
      rb_fifo_flush(&uart_BT_fifo_in, rb_fifo_size(&uart_BT_fifo_in));
      USART_Cmd(USART2, DISABLE);
      Uart_CFG(&USART_InitStructure, baud, parstop);
      USART_Init(USART2, &USART_InitStructure);
      USART_Cmd(USART2, ENABLE);
}



void Uart_U3_Init(u32 baud, u8 parstop)
{
   USART_InitTypeDef USART_InitStructure;
      USART3_Init();
      rb_fifo_flush(&uart_U3_fifo_in, rb_fifo_size(&uart_U3_fifo_in));
      USART_Cmd(USART3, DISABLE);
      Uart_CFG(&USART_InitStructure, baud, parstop);
      USART_Init(USART3, &USART_InitStructure);
      USART_Cmd(USART3, ENABLE);
}

*/


void USART1_GPIO(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
// �������� ������������ ����� � � USART1
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
// TxD (PA9) push-pull With Alternate
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void USART2_GPIO(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
// �������� ������������ ����� � � USART2
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
// TxD (PA2) push-pull With Alternate
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void USART3_GPIO(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
// Port B and USART3
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
// TxD (PB10) push-pull
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
// RxD (PB11) push-pull
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
}


interface_USART_MacroFunctionGenerator(RS,USART1,128,128);
interface_USART_MacroFunctionGenerator(BT,USART2,128,128);
interface_USART_MacroFunctionGenerator(SL,USART3,128,128);



void InterfaceInit(void)
{
}


