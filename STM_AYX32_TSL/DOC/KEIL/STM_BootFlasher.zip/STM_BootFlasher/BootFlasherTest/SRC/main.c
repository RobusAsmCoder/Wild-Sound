//////////////////////////////////////////////////////////////////////////////////////
// By Rob F. / Entire Group
//////////////////////////////////////////////////////////////////////////////////////

#include <string.h>
#include "SysType.h"
#include "hardware.h"
#include "interface.h"
#include "core_UID.h"
#include "BootFlasher.h"



int main(void)
{
    Init();
  
    Uart_RS_Init(460800*0+19200,0x01);
//    Uart_BT_Init(115200,0x01);
    Send_RS_String("\x0D\x0A");
    Send_RS_String("Boot Flasher TEST\x0D\x0A");
    Send_RS_String("Latrax\x0D\x0A");
		Send_RS_String("Enture Group\x0D\x0A");
    {
      Send_RS_String("Flash Size: ");
      Send_RS_DEC(CORE_UID->FlashSizeK*1024);
      Send_RS_String("\x0D\x0A");
      
      Send_RS_String("Device ");
      Send_RS_HEX(CORE_UID->U_ID[0],8);
      Send_RS_Byte(' ');
      Send_RS_HEX(CORE_UID->U_ID[1],8);
      Send_RS_Byte(' ');
      Send_RS_HEX(CORE_UID->U_ID[2],8);
      //05DF2D34 34335746 43033515
      Send_RS_String("\x0D\x0A");
    }
    

    {
      u32 d;
      u32 blocks;
      d = bflBootBlocksGetCRC();
      Send_RS_String("BootFlash Blocks CRC: ");
      Send_RS_HEX(d,4);
      Send_RS_String("\x0D\x0A");
      
      d = bflBootCheckNeedFlashing();
      Send_RS_String("BootFlash Need Boot Flag: ");
      Send_RS_DEC(d);
      Send_RS_String("\x0D\x0A");

      blocks = bflBootBlocks();
      Send_RS_String("BootFlash Number Of Blocks: ");
      Send_RS_DEC(blocks);
      Send_RS_String("\x0D\x0A");
      
      for (u32 n=0; n<blocks; n++)
      {
        //u32 a=bflBootBlockAddr(n);
        t_bfl_BlockRec *blk = bflBootBlockPTR(n);
        blocks = bflBootBlocks();
        Send_RS_String(" Block ADDR: ");
        Send_RS_HEX((u32)&blk[0],8);
        Send_RS_String("\x0D\x0A");
        Send_RS_String("       addr: ");
        Send_RS_HEX(blk->blkadr,8);
        Send_RS_String("\x0D\x0A");
        Send_RS_String("       size: ");
        Send_RS_HEX(blk->blksiz,8);
        Send_RS_String("\x0D\x0A");
        Send_RS_String("       type: ");
        Send_RS_DEC(blk->blktyp);
        Send_RS_String("\x0D\x0A");
/*
        const u32 max=39;
        u32 m;
        for (m=0; m<blk->blksiz; m++)
        {
          if ( (m%max)==0 )
          {
            if (m)
            {
              Send_RS_String("\x0D\x0A");
            }
            Send_RS_String(">");
          }
          Send_RS_HEX(blk->data[m],2);
          if ( (m%max)==0 )
          {
          }
        }
        Send_RS_String("\x0D\x0A");
*/
      }
      
      
      
    }
    
//    Send_RS_String("Go To ReBoot ...\x0D\x0A");
//    DelayMS(100);
//    bflBootExtremalExecFlash();
    
    if (bflBootCheckNeedFlashing())
    {
      if (KEY0()!=0)
      {
        Send_RS_String("Go To Static Boot ...\x0D\x0A");
        DelayMS(500);
        bflBootExtremalExecuteBlockType(BLOCK_TYPES_BOOT_STATIC);
      }
    }
    
    
    bflDataStart();
    while(1)
    {
      u16 w=Read_RS_Byte();
      if (w<0x0100)
      {
//        Send_RS_Byte(w);
        bflDataAddByte((char)w);
      }
    }
    

}





