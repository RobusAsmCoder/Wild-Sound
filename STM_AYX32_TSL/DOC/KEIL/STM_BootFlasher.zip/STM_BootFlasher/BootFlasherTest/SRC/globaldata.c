//////////////////////////////////////////////////////////////////////////////////////
// By Rob F. / Entire Group
// Compile this module only with -c99 flag !
//////////////////////////////////////////////////////////////////////////////////////

#include "SysType.h"
#include "hardware.h"
#include "globaldata.h"

//u32 zub=123490;
//u32 ShowScriptID=flash_file_ID_SCRIPT;


//const char flash_disk_name[]="Flash Disk By Rob F. ID:E698ABAC";
//const u8 font_tmp[]={
//    #include "..\TMT\GFX\F8X8-A.INC"
//    //#include "..\TMT\GFX\FNT6-24.INC"
//};
//const char font_tmp_name[]="F8X8-A";
//u16 font_tmp_ID=0;




