//////////////////////////////////////////////////////////////////////////////////////
// By Rob F. / Entire Group
//////////////////////////////////////////////////////////////////////////////////////

#include "SysType.h"
#include "rb_base64m.h"
#include "BootFlasher.h"


void SystemInit(void)
{
    
}

int main(void)
{
      if (bflBootCheckNeedFlashing())
      {
        bflBootProgramBlockType(BLOCK_TYPES_BOOT_FLASH);
        bflBootProgramBlockType(BLOCK_TYPES_DATA_FLASH);
        bflBootFlashDisable();
      }
      bflBootExtremalExecFlash();
  
      while(1)
      {
        __asm {
          NOP
          NOP
          NOP
          NOP
          NOP
          NOP
          NOP
          NOP
          NOP
          NOP
          NOP
          NOP
        }
      }
}

