//////////////////////////////////////////////////////////////////////////////////////
// By Rob F. / Entire Group
//////////////////////////////////////////////////////////////////////////////////////

#ifndef __BOOTFLASHER_H
#define __BOOTFLASHER_H

#include "SysType.h"

#pragma push
#pragma pack(1)


typedef struct {
  u32 recsize;
  u32 blkadr;
  u32 blksiz;
  u16 blktyp;
  u32 dsize;
  u8 data[];
}t_bfl_BlockRec;


#pragma pop

#define BLOCK_TYPES_BOOT_STATIC       0
#define BLOCK_TYPES_BOOT_FLASH        1
#define BLOCK_TYPES_DATA_FLASH        2


extern void bflDataStart(void);
extern void bflDataAddByte(char c);
extern void bflDataAddBuffer(char *buf, u16 size);

extern u8 bflFlashCompareBlock(u32 addr, void *s, u32 siz);


extern u32 bflBootBlockAddr(u16 bnum);
extern u8 *bflBootBlockPBUF(u16 bnum);
extern t_bfl_BlockRec *bflBootBlockPTR(u16 bnum);
extern u8 bflBootCheckNeedFlashing(void);
extern u16 bflBootBlocksGetCRC(void);
extern u16 bflBootBlocks(void);

extern __asm void bflBootExtremalExec(u8 *dest);
extern __asm void bflBootExtremalCopyExec(u8 *dest, u8 *src, u32 size);
extern void bflBootExtremalExecFlash(void);

extern u16 bflBootFindByType(u16 typ);

extern void bflBootExtremalExecuteBlock(u16 bnum);
extern void bflBootExtremalExecuteBlockType(u16 typ);
extern void bflBootProgramBlock(u16 bnum);
extern void bflBootProgramBlockType(u16 typ);

extern void bflBootFlashDisable(void);

#endif
