//////////////////////////////////////////////////////////////////////////////////////
// By Rob F. / Entire Group
//////////////////////////////////////////////////////////////////////////////////////

#include "SysType.h"
#include "rb_fifo.h"


u8 rb_fifo_rd(Trb_fifo *fif)
{
    u8 c;
    if (fif->buf)
    {
      c=fif->buf[fif->rd++];
      fif->rd &= fif->size_mask;
      return(c);
    } else {
      return(0xFF);
    }
}

u8 rb_fifo_ofs_rd(Trb_fifo *fif, u8 ofs)
{
    if (fif->buf)
    {
      return(fif->buf[(fif->rd+ofs) & fif->size_mask]);
    } else {
      return(0xFF);
    }
}

u8 rb_fifo_rd_blk(Trb_fifo *fif, void *blk, u8 siz)
{
    u8 *s=blk;
    u8 size=0;
    if (fif->buf)
    {
      while (siz)
      {
        if (rb_fifo_size(fif))
        {
          s[size++]=rb_fifo_rd(fif);
        } else break;
        siz--;
      }
    }
    return size;
}

u16 rb_fifo_rd_W(Trb_fifo *fif)
{
    u16 w=0;
    rb_fifo_rd_blk(fif, &w, 2);
    return w;
}

u32 rb_fifo_rd_D(Trb_fifo *fif)
{
    u32 d=0;
    rb_fifo_rd_blk(fif, &d, 4);
    return d;
}

void rb_fifo_flush(Trb_fifo *fif, u8 ofs)
{
    if (fif->buf)
    {
      u8 siz=rb_fifo_size(fif);
      if ( siz < ofs ) ofs=siz;
      fif->rd = (fif->rd+ofs) & fif->size_mask;
    }
}

void rb_fifo_wr(Trb_fifo *fif, u8 c)
{
    if (fif->buf)
    {
      fif->buf[fif->wr++]=c;
      fif->wr &= fif->size_mask;
    }
}

void rb_fifo_wr_blk(Trb_fifo *fif, void *blk, u8 siz)
{
    u8 *s=blk;
    while (siz)
    {
      rb_fifo_wr(fif, s++[0]);
      siz--;
    }
}
void rb_fifo_wr_W(Trb_fifo *fif, u16 w)
{
    rb_fifo_wr_blk(fif, &w, 2);
}
void rb_fifo_wr_D(Trb_fifo *fif, u32 d)
{
    rb_fifo_wr_blk(fif, &d, 4);
}

u8 rb_fifo_size(Trb_fifo *fif)
{
    return ( (fif->wr-fif->rd) & fif->size_mask );
}

u32 rb_fifo_free(Trb_fifo *fif)
{
    return ( fif->size_mask - rb_fifo_size(fif)  );
}

void rb_fifo_wr_wait(Trb_fifo *fif, u8 c)
{
    while ( rb_fifo_free(fif)==0 );
    rb_fifo_wr(fif, c);
}


