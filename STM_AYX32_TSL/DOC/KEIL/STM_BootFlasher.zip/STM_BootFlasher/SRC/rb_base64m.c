//////////////////////////////////////////////////////////////////////////////////////
// By Rob F. / Entire Group
//////////////////////////////////////////////////////////////////////////////////////

#include "SysType.h"
#include "rb_base64m.h"



tBase64m bas64m;

//#include "rb_base64m.h"
//Base64m_Init

void BASE64m_Init(tBase64m *bas, const u8 *bTbl)
{
      bas->bTbl = (u8 *)bTbl;
}

//char to byte
u8 BASE64_T_TBD(tBase64m *bas, u8 N)
{
    u8 i=0;
    u8 b;
    while( (b=bas->bTbl[i])!=0 )
    {
      if (b==N)
      {
        return i;
      }
      i++;
    }
    return 0;
}


//char to byte
//u8 BASE64_T_TBE(tBase64m *bas, u8 N)
//{
//    return bas->bTbl[N];
//}
#define BASE64_T_TBE(_bas, _N)    _bas->bTbl[_N]


u32 BASE64m_EnCode(tBase64m *bas, char *s, u8 *buf, u32 si)
{
    u32 n,m;
    u16 B;
    u32 ss=0;
    m=0;
    n=0;
    while(n<si)//WHILE N<=Length(S) DO BEGIN
    {
     switch (m & 3)
     {
      case 0:
       B=buf[n];      //BYTE(S[N]);
       n++;
       s[ss++] = BASE64_T_TBE(bas, B & 63);//RESULT:=RESULT+CHAR(BASE64_T_TBE[B AND 63]);
       B>>=6;//B:=B SHR 6;
       s[ss++] = BASE64_T_TBE(bas, B);//RESULT:=RESULT+CHAR(BASE64_T_TBE[B]);
       break;
      case 1:
       B |= buf[n] << 2;//B:=B OR (BYTE(S[N]) SHL 2);
       n++;
       s[ss-1] = BASE64_T_TBE(bas, B & 63);//RESULT[Length(RESULT)]:=CHAR(BASE64_T_TBE[B AND 63]);
       B>>=6;//B:=B SHR 6;
       s[ss++] = BASE64_T_TBE(bas, B);//RESULT:=RESULT+CHAR(BASE64_T_TBE[B]);
       break;
      case 2:
       B |= buf[n] << 4;//B:=B OR (BYTE(S[N]) SHL 4);
       n++;
       s[ss-1] = BASE64_T_TBE(bas, B & 63);//RESULT[Length(RESULT)]:=CHAR(BASE64_T_TBE[B AND 63]);
       B>>=6;//B:=B SHR 6;
       s[ss++] = BASE64_T_TBE(bas, B);//RESULT:=RESULT+CHAR(BASE64_T_TBE[B]);
       m++;
       break;
     }
     m++;
    }
    s[ss] = 0;
    return ss;
}

u32 BASE64m_DeCode(tBase64m *bas, char *s, u8 *buf)
{
    u32 n,m;
    u16 B=0;
    u32 si=0;
    n=0;
    m=0;
    u8 c;
    while ((c=s[n])!=0)
    {
     switch (m & 3)
     {
      case 0:
       B = BASE64_T_TBD(bas, c)<<8;//B:=BASE64_T_TBD[BYTE(S[N])] SHL 8;
       break;
      case 1:
       B|= BASE64_T_TBD(bas, c)<<6;//B:=B OR (BASE64_T_TBD[BYTE(S[N])] SHL 6);
       buf[si++]=B;//RESULT:=RESULT + CHAR(B AND 255);
       break;
      case 2:
       B|= BASE64_T_TBD(bas, c)<<4;//B:=B OR (BASE64_T_TBD[BYTE(S[N])] SHL 4);
       buf[si++]=B;//RESULT:=RESULT + CHAR(B AND 255);
       break;
      case 3:
       B|= BASE64_T_TBD(bas, c)<<2;//B:=B OR (BASE64_T_TBD[BYTE(S[N])] SHL 2);
       buf[si++]=B;//RESULT:=RESULT + CHAR(B AND 255);
       break;
     }
     B>>=8;//B:=B SHR 8;
     n++;
     m++;
    }
    return si;
}






