//////////////////////////////////////////////////////////////////////////////////////
// By Rob F. / Entire Group
//////////////////////////////////////////////////////////////////////////////////////

#ifndef __RB_BASE64M_H
#define __RB_BASE64M_H

#include "SysType.h"

#define BASE64_T_DEF    "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!#" //$%&()*+,-./:;<=>?[\\]^_@"

typedef struct {
    u8 *bTbl;
}tBase64m;

extern tBase64m bas64m;

extern void BASE64m_Init(tBase64m *bas, const u8 *bTbl);
extern u32 BASE64m_EnCode(tBase64m *bas, char *s, u8 *buf, u32 si);
extern u32 BASE64m_DeCode(tBase64m *bas, char *s, u8 *buf);



#endif
