
#pragma once

#define STM32F4XX

#include "../bits/device_select.tcc"
