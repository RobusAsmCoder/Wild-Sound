# arm
Misc projects for ARM family

libstm32pp initially created by Jorge Aparicio, now seems to be unsupported by the author.
Here is my branch with many updates, bug fixes, additions.
