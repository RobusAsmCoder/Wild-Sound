
package ibxm;

public class GlobalVol {
	public int volume;
}
