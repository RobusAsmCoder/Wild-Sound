
void pattern_display_close();
int pattern_display_open();
int pattern_display_get_mute();
void pattern_display_redraw_event( SDL_Event *event, struct module *module );
void pattern_display_button_event( SDL_Event *event, struct module *module );
